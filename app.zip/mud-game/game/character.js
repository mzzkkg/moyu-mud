'use strict';
const { ITEMS, itemDef } = require('../data/items');
const { clamp, rint, chance, rnd } = require('./util');

const SKILL_NAMES = {
  firstaid: '急救', stealth: '潜行', firearms: '枪械', forge: '锻造', scout: '侦查', melee: '近战',
};

const INJURY_NAMES = {
  abrasion: '擦伤',
  laceration: '撕裂伤',
  fracture: '骨折',
  internal: '内脏伤',
};

function createCharacter(name, id) {
  const ch = {
    id,
    name,
    loc: 'jiezi',
    hp: 96,
    hunger: 82,
    thirst: 78,
    stamina: 100,
    infection: 0,
    pain: 0,
    sanity: 88,
    injuries: [],
    attrs: { str: 5, agi: 5, con: 5, per: 5 },
    level: 1,
    xp: 0,
    points: 0,
    skills: { firstaid: 0, stealth: 0, firearms: 0, forge: 0, scout: 0, melee: 0 },
    inv: [],
    hideout: { loc: null, storage: [], buildings: {}, looted: {} },
    party: null,
    alive: true,
    dead: false,
    deathCount: 0,
    stats: { kills: 0, searches: 0, distance: 0, crafted: 0 },
    flags: { rest: false, flashlight: false, maskWorn: true },
    createdAt: Date.now(),
    lastAction: 0,
    lastSeen: Date.now(),
    pendingRumor: null,
  };
  addItem(ch, 'bandage', 2);
  addItem(ch, 'biscuit', 2);
  addItem(ch, 'bottled', 1);
  addItem(ch, 'pipe', 1, null, 'weapon');
  addItem(ch, 'lighter', 1);
  addItem(ch, 'cloth', 1);
  ch.hp = derived(ch).hpMax;
  return ch;
}

function derived(ch) {
  const fracture = ch.injuries.some(i => i.type === 'fracture');
  const internal = ch.injuries.some(i => i.type === 'internal');
  const hpMax = Math.round(80 + ch.attrs.con * 6 + (ch.level - 1) * 6 - (internal ? 8 : 0));
  const staminaMax = Math.round((80 + ch.attrs.con * 4 + ch.attrs.agi * 2 + (ch.level - 1) * 4) * (fracture ? 0.62 : 1));
  const cap = Math.round((14 + ch.attrs.str * 3) * 10) / 10;
  const load = Math.round(ch.inv.reduce((s, it) => s + itemDef(it.id).w * it.qty, 0) * 10) / 10;
  const weapon = getWeapon(ch);
  const armor = getArmor(ch);
  const bleed = ch.injuries.some(i => i.bleed);
  const overload = load > cap ? (load - cap) / cap : 0;
  const perception = Math.max(0.2, 1 - overload * 0.3) * (0.85 + ch.attrs.per * 0.03);
  return {
    hpMax, staminaMax, cap, load, overload, weapon, armor, bleed, perception,
    fracture, internal,
    speed: overload > 0 ? 0.7 : 1,
    noise: 1 + Math.floor(overload * 3),
  };
}

function getWeapon(ch) {
  const slot = ch.inv.find(s => s.eq === 'weapon' && s.qty > 0);
  return slot ? slot.id : 'fists';
}
function getArmor(ch) {
  let a = 0;
  for (const s of ch.inv) {
    if ((s.eq === 'armor' || s.eq === 'head') && s.qty > 0) a += itemDef(s.id).armor || 0;
  }
  return a;
}
function getMask(ch) {
  const slot = ch.inv.find(s => s.eq === 'mask' && s.qty > 0);
  return slot ? slot.id : null;
}

function findSlot(ch, id) {
  return ch.inv.find(s => s.id === id && s.qty > 0);
}
function countItem(ch, id) {
  return ch.inv.reduce((s, it) => s + (it.id === id ? it.qty : 0), 0);
}
function hasItems(ch, need) {
  return Object.entries(need || {}).every(([id, q]) => countItem(ch, id) >= q);
}

function addItem(ch, id, qty = 1, dec = null, eq = null) {
  const def = itemDef(id);
  const d = dec != null ? dec : (def.dec || null);
  const slot = ch.inv.find(s => s.id === id && (def.dec ? true : true));
  if (slot) {
    slot.qty += qty;
    if (def.dec && d != null) slot.dec = Math.min(slot.dec == null ? d : slot.dec, d);
  } else {
    ch.inv.push({ id, qty, dec: def.dec ? d : null, eq });
  }
  if (eq) equipSlot(ch, id, eq);
  return true;
}

function equipSlot(ch, id, slotType) {
  for (const s of ch.inv) {
    if (s.eq === slotType && s.id !== id) s.eq = null;
  }
  const target = ch.inv.find(s => s.id === id);
  if (target) target.eq = slotType;
}

function removeItem(ch, id, qty = 1) {
  let need = qty;
  for (const s of ch.inv) {
    if (s.id !== id || need <= 0) continue;
    const take = Math.min(s.qty, need);
    s.qty -= take;
    need -= take;
  }
  ch.inv = ch.inv.filter(s => s.qty > 0);
  return need === 0;
}

function consumeItem(ch, id, qty = 1) {
  if (!removeItem(ch, id, qty)) return false;
  return true;
}

function equip(ch, id) {
  const def = itemDef(id);
  if (!findSlot(ch, id)) return { ok: false, msg: '你身上没有这件装备。' };
  let slot = null;
  if (def.type === 'weapon') slot = 'weapon';
  else if (def.type === 'armor') slot = def.slot === 'head' ? 'head' : 'armor';
  else if (def.type === 'mask') slot = 'mask';
  else return { ok: false, msg: `${def.name} 不能装备。` };
  equipSlot(ch, id, slot);
  return { ok: true, msg: `你换上了 ${def.name}。` };
}

function takeDamage(ch, amount, opts = {}) {
  const armor = getArmor(ch) + (opts.armorBonus || 0);
  const armorPierce = opts.pierce || 0;
  const effectiveArmor = Math.max(0, armor - armorPierce);
  const reduced = Math.max(1, Math.round(amount - effectiveArmor * 0.9));
  ch.hp -= reduced;
  ch.pain = clamp(ch.pain + Math.round(reduced * 0.6), 0, 100);
  let injury = null;
  if (opts.injuryChance != null && chance(opts.injuryChance)) {
    const types = opts.kind === 'zombie' ? ['abrasion', 'laceration', 'laceration', 'fracture'] : ['abrasion', 'laceration', 'internal'];
    const type = opts.injuryType || types[rint(0, types.length - 1)];
    injury = addInjury(ch, type, rint(4, 9));
  }
  if (ch.hp <= 0) {
    ch.hp = 0;
  }
  return { reduced, injury };
}

function addInjury(ch, type, sev = 6) {
  const existing = ch.injuries.find(i => i.type === type);
  if (existing) {
    existing.sev += sev;
  } else {
    ch.injuries.push({ type, sev, bleed: type === 'laceration' && chance(0.8), treated: 0 });
  }
  return INJURY_NAMES[type] || type;
}

function heal(ch, amount) {
  const d = derived(ch);
  ch.hp = clamp(ch.hp + amount, 0, d.hpMax);
}

function applyEffects(ch, eff = {}) {
  const d = derived(ch);
  if (eff.hunger) ch.hunger = clamp(ch.hunger + eff.hunger, 0, 100);
  if (eff.thirst) ch.thirst = clamp(ch.thirst + eff.thirst, 0, 100);
  if (eff.hp) {
    if (eff.hp > 0) heal(ch, eff.hp);
    else ch.hp = Math.max(0, ch.hp + eff.hp);
  }
  if (eff.infection) ch.infection = clamp(ch.infection + eff.infection, 0, 100);
  if (eff.sanity) ch.sanity = clamp(ch.sanity + eff.sanity, 0, 100);
  if (eff.pain) ch.pain = clamp(ch.pain + eff.pain, 0, 100);
  if (eff.stamina) ch.stamina = clamp(ch.stamina + eff.stamina, 0, d.staminaMax);
}

function useItem(ch, id, room) {
  const def = itemDef(id);
  if (!findSlot(ch, id)) return { ok: false, msg: '你身上没有这件东西。' };
  const d = derived(ch);
  const log = [];

  if (def.type === 'food' || def.type === 'water') {
    const slot = findSlot(ch, id);
    if (slot.dec != null && slot.dec <= 0) {
      removeItem(ch, id, slot.qty);
      return { ok: false, msg: `${def.name} 已经腐烂发臭，你只能把它扔掉。` };
    }
    consumeItem(ch, id, 1);
    applyEffects(ch, def.eff || {});
    log.push(`你吃下了 ${def.name}。`);
    if (id === 'dirty') {
      if (room) room.noiseFlag = true;
      if (chance(0.35)) {
        ch.infection = clamp(ch.infection + 6, 0, 100);
        log.push('水里有股铁锈和腐臭混在一起的味道，你的胃一阵翻搅。');
      }
    } else if (id === 'rainwater') {
      if (chance(0.2)) {
        ch.infection = clamp(ch.infection + 4, 0, 100);
        log.push('水面上那层灰进到喉咙里，你咳了两声。');
      }
    }
    if (def.eff && def.eff.hunger) log.push(`饥饿感稍微退去了一些。（饥饿 ${Math.round(ch.hunger)}）`);
    if (def.eff && def.eff.thirst) log.push(`喉咙不再干得发疼。（口渴 ${Math.round(ch.thirst)}）`);
    return { ok: true, msg: log.join('\n'), effects: def.eff };
  }

  if (id === 'water_tab') {
    const dirty = findSlot(ch, 'dirty');
    if (!dirty) return { ok: false, msg: '你身上没有需要净化的脏水。' };
    consumeItem(ch, 'dirty', 1);
    consumeItem(ch, 'water_tab', 1);
    addItem(ch, 'water', 1);
    return { ok: true, msg: '你把净水片丢进脏水，等了一会儿，水面上浮起一层细小的气泡。现在它勉强能喝了。' };
  }

  if (def.type === 'med') {
    const med = def.med || {};
    let treated = false;
    if (med.stopBleed) {
      for (const i of ch.injuries) {
        if (i.bleed) { i.bleed = false; treated = true; }
      }
    }
    if (med.injury) {
      const target = med.injury === 'all'
        ? ch.injuries.find(i => i.sev > 0)
        : ch.injuries.find(i => i.type === med.injury);
      if (target) { target.sev = Math.max(0, target.sev - (med.amount || 0)); treated = true; }
    }
    if (med.heal) heal(ch, med.heal);
    applyEffects(ch, def.eff || {});
    ch.injuries = ch.injuries.filter(i => i.sev > 0 || i.bleed);
    consumeItem(ch, id, 1);
    log.push(`你用了 ${def.name}。`);
    if (treated) log.push('伤口传来一阵清凉的刺痛，血止住了，或者至少不再流得那么快。');
    return { ok: true, msg: log.join('\n') };
  }

  if (def.type === 'tool' && id === 'flashlight') {
    ch.flags.flashlight = !ch.flags.flashlight;
    if (ch.flags.flashlight && countItem(ch, 'battery') <= 0) {
      ch.flags.flashlight = false;
      return { ok: false, msg: '手电没电了。你该找几节电池。' };
    }
    return { ok: true, msg: ch.flags.flashlight ? '手电亮起，光柱切开黑暗。' : '你关掉了手电，四周重新陷入黑暗。' };
  }

  return { ok: false, msg: `${def.name} 不能直接使用，也许可以用它制作别的东西。` };
}

function gainXp(ch, amount) {
  ch.xp += amount;
  let leveled = 0;
  let need = 80 + 40 * (ch.level - 1);
  while (ch.xp >= need) {
    ch.xp -= need;
    ch.level += 1;
    ch.points += 1;
    leveled += 1;
    need = 80 + 40 * (ch.level - 1);
  }
  if (leveled) {
    ch.hp = derived(ch).hpMax;
    ch.stamina = derived(ch).staminaMax;
  }
  return leveled;
}

function trainSkill(ch, key, amount = 1) {
  if (!ch.skills[key]) ch.skills[key] = 0;
  if (ch.skills[key] >= 10) return false;
  if (chance(0.35 * amount)) {
    ch.skills[key] += 1;
    return true;
  }
  return false;
}

function skillName(k) { return SKILL_NAMES[k] || k; }

/** 每次游戏刻（1 秒 = 2 游戏分钟）调用 */
function tickCharacter(ch, hoursDelta, ctx = {}) {
  const d = derived(ch);
  const logs = [];
  ch.hunger = clamp(ch.hunger - 2.1 * hoursDelta, 0, 100);
  ch.thirst = clamp(ch.thirst - 2.9 * hoursDelta, 0, 100);

  if (ch.hunger <= 0) {
    ch.hp -= 3.2 * hoursDelta;
    if (chance(0.02)) logs.push('胃里空得发疼，你的手开始发抖。');
    ch.stamina = Math.max(0, ch.stamina - 4 * hoursDelta);
  }
  if (ch.thirst <= 0) {
    ch.hp -= 4.5 * hoursDelta;
    if (chance(0.02)) logs.push('嘴唇裂开了，舌头像砂纸。你必须找到水。');
  }

  // 出血
  for (const inj of ch.injuries) {
    if (inj.bleed) {
      ch.hp -= 7 * hoursDelta;
      ch.pain = clamp(ch.pain + 4 * hoursDelta, 0, 100);
    }
    if (inj.type === 'internal') {
      ch.hp -= 2.2 * hoursDelta;
      ch.pain = clamp(ch.pain + 1.5 * hoursDelta, 0, 100);
    }
    if (inj.type === 'laceration' && !inj.bleed && inj.treated === 0) {
      // 未处理的伤口在雨天容易发炎
      if (ctx.rain) {
        inj.treated = 1;
        ch.infection = clamp(ch.infection + 5, 0, 100);
        logs.push('雨水泡开了伤口，边缘发白，感染更深了。');
      }
    }
  }

  // 感染
  if (ch.infection > 0) {
    ch.infection = clamp(ch.infection, 0, 100);
    if (ch.infection >= 20 && ch.infection < 40 && chance(0.03)) logs.push('你感到一阵发冷，像是在发烧。');
    if (ch.infection >= 40 && chance(0.04)) logs.push('视线边缘有黑色的东西在游动，你揉了揉眼睛，它还在。');
    if (ch.infection >= 60) {
      ch.infection = clamp(ch.infection + 0.6 * hoursDelta, 0, 100);
      if (chance(0.05)) logs.push('手指关节发僵，皮肤下的血管变成暗紫色。');
    }
    if (ch.infection >= 100) {
      ch.mutating = true;
    }
  }

  // 疼痛与精神
  ch.pain = clamp(ch.pain - 2.5 * hoursDelta, 0, 100);
  let sanityDelta = 0;
  if (ctx.night && !ctx.shelter) sanityDelta -= 2.2;
  if (ctx.rain) sanityDelta -= 0.4;
  if (ctx.party) sanityDelta += 0.8;
  if (ch.pain > 60) sanityDelta -= 1.5;
  if (ch.infection > 50) sanityDelta -= 1.2;
  if (ch.hunger < 20) sanityDelta -= 1.0;
  ch.sanity = clamp(ch.sanity + sanityDelta * hoursDelta, 0, 100);

  // 体力
  if (ch.flags.rest) {
    ch.stamina = clamp(ch.stamina + 28 * hoursDelta, 0, d.staminaMax);
  } else {
    ch.stamina = clamp(ch.stamina + 5 * hoursDelta, 0, d.staminaMax);
  }
  if (ch.stamina > d.staminaMax) ch.stamina = d.staminaMax;

  // 自然愈合
  if (ch.hunger > 60 && ch.thirst > 50 && !d.bleed) {
    ch.hp = clamp(ch.hp + (ch.flags.rest ? 3.2 : 0.9) * hoursDelta, 0, d.hpMax);
  }

  // 食物腐烂
  for (const s of ch.inv) {
    if (s.dec != null) {
      s.dec -= hoursDelta;
      if (s.dec <= 0) {
        logs.push(`${itemDef(s.id).name} 已经变质，散发出一股酸臭味。`);
        s.qty = 0;
      }
    }
  }
  ch.inv = ch.inv.filter(s => s.qty > 0);

  if (ch.hp <= 0 && ch.alive) ch.hp = 0;
  return logs;
}

module.exports = {
  createCharacter, derived, getWeapon, getArmor, getMask,
  addItem, removeItem, consumeItem, countItem, hasItems, findSlot,
  takeDamage, addInjury, heal, applyEffects, useItem, equip,
  gainXp, trainSkill, skillName, tickCharacter,
  SKILL_NAMES, INJURY_NAMES,
};
