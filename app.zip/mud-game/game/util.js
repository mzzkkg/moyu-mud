'use strict';

const rnd = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.floor(rnd(a, b + 1));
const chance = (p) => Math.random() < p;
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const uid = (n = 8) => Math.random().toString(36).slice(2, 2 + n);

function weighted(list, wkey = 'w') {
  const total = list.reduce((s, it) => s + (it[wkey] || 0), 0);
  if (total <= 0) return list[0];
  let r = Math.random() * total;
  for (const it of list) {
    r -= (it[wkey] || 0);
    if (r <= 0) return it;
  }
  return list[list.length - 1];
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

module.exports = { rnd, rint, chance, pick, clamp, uid, weighted, shuffle };
