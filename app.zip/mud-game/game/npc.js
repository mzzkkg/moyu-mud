'use strict';
const { rint, chance, pick, clamp } = require('./util');
const { itemDef } = require('../data/items');
const C = require('./character');

const PROFILES = {
  trader: {
    names: ['老陈', '徐掌柜', '跛脚刘'],
    desc: '他把一个旧行李箱当柜台，箱盖上摆着几样东西，用石头压着防止被风吹走。',
    lines: ['东西不多，但都是能救命的。你要是有货，可以换。', '这年头钱没用，命才有用。你带什么来了？', '别在我这儿磨蹭太久，天黑之前我得走。'],
    stock: [['bandage', 2], ['water', 2], ['antibiotics', 1], ['lighter', 1], ['pistol_ammo', 5], ['battery', 2], ['plank', 3], ['tape', 1]],
    route: ['jiezi', 'chaoshi', 'bihansuo', 'xuexiao'],
  },
  medic: {
    names: ['林医生', '白露', '周护士'],
    desc: '她穿着洗得发白的白大褂，袖口用别针别着，手上还戴着半截医用手套。',
    lines: ['你伤得不轻，先坐下。别逞强。', '药我还有一些，但不多。你拿东西换，或者帮我做件事。', '感染值超过六十就别硬撑了，那时候我只能给你缝合。'],
    stock: [['bandage', 3], ['antibiotics', 1], ['splint', 1], ['painkiller', 2], ['suture', 1]],
    route: ['bihansuo', 'yiyuan', 'jiezi'],
  },
  orderly: {
    names: ['赵队', '韩班长', '老周'],
    desc: '他臂上缠着红布条，背着步枪，站姿很直，像是当过兵。',
    lines: ['这片区域我们还在管。你守规矩，我们就不是敌人。', '前面两个街区不太平，入夜之后别在外面晃。', '如果你愿意，可以帮我们清一片区域，我给得起报酬。'],
    stock: [['mre', 1], ['rifle_ammo', 5], ['vest', 1], ['medkit', 1]],
    route: ['bihansuo', 'jiezi', 'jingju', 'shoufeizhan'],
  },
  scavenger: {
    names: ['小满', '阿七', '瘦猴'],
    desc: '他背着一个比他还大的编织袋，看见你时下意识护住了袋口。',
    lines: ['我什么都没拿，真的。', '前面那家超市我昨天去过，货架空了。后仓我没敢进。', '你要是给我点吃的，我告诉你一个地方。'],
    stock: [['biscuit', 2], ['bottled', 1], ['tape', 1], ['note', 1]],
    route: ['chaoshi', 'cangku', 'matou', 'jiezi'],
  },
  raider: {
    names: ['刀疤', '黑皮', '独眼'],
    desc: '他脸上横着一道从眉骨到下巴的疤，手里那根钢管上还沾着干掉的血。',
    lines: ['把包放下，人可以走。', '这片地方归我们了。你踩进来了。', '别装了，我看见你背包里那罐头了。'],
    stock: [['pistol_ammo', 4], ['knife', 1], ['can', 2]],
    route: ['jingju', 'gongyu', 'shoufeizhan', 'cangku'],
  },
};

function createNPCs() {
  const npcs = [];
  let i = 0;
  for (const [kind, prof] of Object.entries(PROFILES)) {
    const count = kind === 'raider' ? 2 : 1;
    for (let k = 0; k < count; k++) {
      npcs.push({
        id: 'npc' + i++,
        kind,
        name: prof.names[k % prof.names.length],
        desc: prof.desc,
        lines: prof.lines,
        loc: prof.route[0],
        route: prof.route,
        routeIdx: 0,
        moveAt: 0,
        hp: kind === 'raider' ? 70 : 80,
        affinity: {},
        stock: prof.stock.map(([id, qty]) => ({ id, qty, price: Math.max(3, Math.round(itemDef(id).w * 12) + rint(2, 6)) })),
        quest: null,
        alive: true,
        talkCount: 0,
      });
    }
  }
  return npcs;
}

function npcTick(room) {
  const world = room.world;
  for (const npc of world.npcs) {
    if (!npc.alive) continue;
    npc.moveAt = (npc.moveAt || 0) - 1;
    if (npc.moveAt <= 0) {
      npc.moveAt = rint(6, 14);
      const next = npc.route[(npc.routeIdx + 1) % npc.route.length];
      if (next && next !== npc.loc) {
        npc.loc = next;
        npc.routeIdx = (npc.routeIdx + 1) % npc.route.length;
        if (npc.kind !== 'raider' && room.playersInLoc(next).length) {
          room.feed(`${npc.name} 走进了 ${room.locName(next)}，脚步很轻。`);
        }
      }
    }
    // NPC 之间相遇
    const other = world.npcs.find(n => n !== npc && n.alive && n.loc === npc.loc);
    if (other && chance(0.03)) {
      const hostile = (npc.kind === 'raider' && other.kind !== 'raider') || (other.kind === 'raider' && npc.kind !== 'raider');
      if (hostile) {
        const victim = npc.hp < other.hp ? npc : other;
        victim.hp -= rint(10, 28);
        if (victim.hp <= 0) {
          victim.alive = false;
          room.feed(`远处传来一声闷响。等你再看时，${victim.name} 已经倒在 ${room.locName(victim.loc)} 的地上，东西散了一地。`);
          room.dropCorpse(victim.loc, victim.name, victim.stock);
        }
        if (room.playersInLoc(npc.loc).length) {
          room.feed(`${room.locName(npc.loc)} 传来争吵和扭打的声音——${npc.name} 和 ${other.name} 打起来了。`);
        }
      }
    }
  }
}

function talk(player, npc, room) {
  const lines = [];
  npc.talkCount += 1;
  const aff = (npc.affinity[player.id] || 0);
  if (npc.kind === 'raider') {
    lines.push(`${npc.name} 眯起眼睛看你："你也想在这儿捡东西？交出你身上一半的物资，我不为难你。"`);
    if (aff <= 0 && chance(0.5)) {
      lines.push(`${npc.name} 把钢管在掌心敲了敲，慢慢朝你走过来。`);
      return { lines, startCombat: true, npc };
    }
    return { lines, startCombat: false, npc };
  }
  lines.push(`${npc.name}：${pick(npc.lines)}`);
  if (npc.kind === 'trader') {
    lines.push(`他把箱子盖上的石头挪开，露出摆得整整齐齐的货：${npc.stock.filter(s => s.qty > 0).map(s => itemDef(s.id).name).join('、')}。`);
  }
  if (npc.kind === 'medic') {
    lines.push('她抬了抬下巴，示意你把手上的伤口给她看看。');
  }
  if (npc.kind === 'orderly') {
    lines.push('他把枪口压低了一点："有事说事。"');
  }
  if (npc.kind === 'scavenger') {
    lines.push('他咽了口唾沫，眼睛盯着你的背包。');
  }
  npc.affinity[player.id] = clamp(aff + 1, -5, 10);
  if (!npc.quest && npc.kind !== 'raider' && aff >= 0 && chance(0.65)) {
    npc.quest = makeQuest(npc);
    lines.push(`"对了，"他压低声音，"我有个事想请人帮忙。"`);
  }
  return { lines, npc };
}

function makeQuest(npc) {
  const kinds = [
    { type: 'fetch', item: 'bandage', qty: 3, title: '三卷绷带', reward: 'antibiotics', desc: '他需要三卷绷带，有人受了伤，血止不住。' },
    { type: 'fetch', item: 'water', qty: 2, title: '两壶净水', reward: 'mre', desc: '地下的储水快见底了，需要干净的水。' },
    { type: 'fetch', item: 'battery', qty: 2, title: '两节电池', reward: 'flashlight', desc: '电台的电池快耗尽了，他想再听一次外面的声音。' },
  ];
  const q = pick(kinds);
  return {
    id: 'q' + Math.random().toString(36).slice(2, 6),
    giver: npc.id,
    type: q.type,
    item: q.item,
    qty: q.qty,
    title: q.title,
    desc: q.desc,
    reward: q.reward,
    claimable: false,
  };
}

function trade(player, npc, takeIdx, giveId, giveQty = 1) {
  if (npc.kind === 'raider') return { ok: false, msg: '他只想抢，不想换。' };
  const stock = npc.stock[takeIdx];
  if (!stock || stock.qty <= 0) return { ok: false, msg: '那件东西已经不在货单上了。' };
  if (C.countItem(player, giveId) < giveQty) return { ok: false, msg: '你身上的东西不够。' };
  const giveDef = itemDef(giveId);
  const giveValue = Math.round((giveDef.w * 10 + 2) * giveQty);
  if (giveValue < stock.price) {
    return { ok: false, msg: `${npc.name} 掂了掂你给的东西，摇头："这些不够，我要值 ${stock.price} 的货。"` };
  }
  C.removeItem(player, giveId, giveQty);
  C.addItem(player, stock.id, 1);
  stock.qty -= 1;
  return {
    ok: true,
    msg: `你把 ${giveQty} 个 ${giveDef.name} 递过去。${npc.name} 仔细看了看，收进箱子，把 ${itemDef(stock.id).name} 推到你面前。\n"拿好，别死在我看不见的地方。"`,
  };
}

function checkQuest(player, npc) {
  if (!npc.quest || npc.quest.claimed) return null;
  const q = npc.quest;
  if (!q.claimable) {
    if (C.countItem(player, q.item) >= q.qty) {
      q.claimable = true;
      return { ready: true, msg: `${npc.name} 眼睛一亮："你真带来了？"——现在可以交给他了。` };
    }
    return null;
  }
  return { ready: true, msg: '' };
}

function completeQuest(player, npc) {
  const q = npc.quest;
  if (!q || q.claimed) return { ok: false, msg: '没有可以交付的委托。' };
  if (!q.claimable) return { ok: false, msg: '你还没凑齐他要的东西。' };
  C.removeItem(player, q.item, q.qty);
  C.addItem(player, q.reward, 1);
  q.claimed = true;
  npc.affinity[player.id] = (npc.affinity[player.id] || 0) + 3;
  return { ok: true, msg: `你把 ${q.qty} 个 ${itemDef(q.item).name} 放在他面前。他数了数，从怀里掏出 ${itemDef(q.reward).name} 塞给你。\n"以后有事，可以来找我。"` };
}

module.exports = { createNPCs, npcTick, talk, trade, checkQuest, completeQuest, PROFILES };
