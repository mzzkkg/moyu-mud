'use strict';
const fs = require('fs');
const path = require('path');
const { LOCATIONS, START_LOC, locDef, exitCost } = require('../data/world');
const { ITEMS, itemDef } = require('../data/items');
const { RECIPES, BUILDINGS, CAMPFIRE_RECIPES } = require('../data/crafting');
const { ENEMIES } = require('../data/enemies');
const { rint, chance, pick, clamp, uid } = require('./util');
const C = require('./character');
const CB = require('./combat');
const NPC = require('./npc');

const WEATHER = {
  clear: { name: '晴', desc: '天色清亮，风里带着灰尘和铁锈的味道。' },
  cloudy: { name: '阴', desc: '云层压得很低，光线像蒙了一层脏玻璃。' },
  rain: { name: '雨', desc: '雨点砸在废墟上，溅起细小的泥雾。伤口在这种天气里更容易发炎。' },
  fog: { name: '雾', desc: '白雾贴着地面流动，三十米外的东西只剩下轮廓。' },
  sandstorm: { name: '沙尘暴', desc: '黄沙抽在脸上像细小的针，能见度不到十米。' },
};

const AMBIENT = [
  '远处传来一声闷响，像是某栋楼又塌了一角。',
  '风穿过空楼，发出很长的呜咽声。',
  '几只乌鸦从屋顶上飞起，扑棱棱地散开。',
  '你听见很远的地方有枪声，两三下，然后就没了。',
  '空气里有一股潮湿的霉味，从某个看不见的缝隙里渗出来。',
  '地上的影子慢慢挪动，太阳正在往楼群后面沉。',
  '某个窗户里传来玻璃被风吹动的轻响。',
  '一具早已风干的尸体靠在墙边，手里还握着一把钥匙。',
];

class Room {
  constructor(code, dataDir) {
    this.code = code;
    this.dataDir = dataDir;
    this.file = path.join(dataDir, code + '.json');
    this.players = new Map();      // id -> character
    this.conns = new Map();        // id -> ws
    this.lastSave = 0;
    this.lastBroadcast = 0;
    this.tickCount = 0;
    this.loaded = false;
    if (!this.load()) {
      this.world = {
        clockMin: 8 * 60,
        day: 1,
        weather: 'clear',
        weatherUntil: 240,
        containers: {},
        npcs: NPC.createNPCs(),
        corpses: {},
        ground: {},
        rumors: [],
        specialContainers: {},
        feed: [],
        lastRaidHour: 0,
        lastRefresh: 0,
        noise: {},
      };
      for (const id of Object.keys(LOCATIONS)) {
        const st = {};
        for (const c of LOCATIONS[id].containers) st[c.key] = { left: c.cap };
        this.world.containers[id] = st;
      }
      this.feed('末世第五年，榕城。城市已经死了，但还没有凉透。');
    }
    this.loaded = true;
  }

  /* ---------------- 存取 ---------------- */
  load() {
    try {
      if (!fs.existsSync(this.file)) return false;
      const data = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.world = data.world;
      this.world.specialContainers = this.world.specialContainers || {};
      this.saveData = data.chars || [];
      for (const ch of this.saveData) {
        ch.combat = null;
        ch.invites = ch.invites || [];
        this.players.set(ch.id, ch);
      }
      return true;
    } catch (e) {
      console.error('读取房间失败', this.code, e.message);
      return false;
    }
  }

  save(force = false) {
    const now = Date.now();
    if (!force && now - this.lastSave < 20000) return;
    this.lastSave = now;
    try {
      if (!fs.existsSync(this.dataDir)) fs.mkdirSync(this.dataDir, { recursive: true });
      const chars = [];
      for (const ch of this.players.values()) {
        const copy = Object.assign({}, ch);
        copy.combat = null;
        chars.push(copy);
      }
      const data = { code: this.code, savedAt: now, world: this.world, chars };
      fs.writeFileSync(this.file, JSON.stringify(data), 'utf8');
    } catch (e) {
      console.error('保存失败', e.message);
    }
  }

  /* ---------------- 时间与天气 ---------------- */
  get hour() { return Math.floor((this.world.clockMin % 1440) / 60); }
  get minute() { return Math.floor(this.world.clockMin % 60); }
  get day() { return 1 + Math.floor(this.world.clockMin / 1440); }
  get isNight() { const h = this.hour; return h >= 19 || h < 6; }
  timeStr() {
    return `第 ${this.day} 天 ${String(this.hour).padStart(2, '0')}:${String(this.minute).padStart(2, '0')}`;
  }
  weatherInfo() { return WEATHER[this.world.weather] || WEATHER.clear; }

  /* ---------------- 消息 ---------------- */
  send(id, obj) {
    const conn = this.conns.get(id);
    if (conn && !conn.closed) conn.send(obj);
  }
  log(id, lines, kind = 'narr') {
    if (!lines || !lines.length) return;
    this.send(id, { t: 'log', lines, kind });
  }
  feed(text) {
    const w = this.world;
    w.feed.unshift(`[${this.timeStr()}] ${text}`);
    if (w.feed.length > 40) w.feed.length = 40;
  }
  broadcast(obj) {
    for (const [id, conn] of this.conns) {
      if (!conn.closed) conn.send(obj);
    }
  }
  locName(id) { return (LOCATIONS[id] || {}).name || '未知区域'; }
  playersInLoc(locId) {
    const out = [];
    for (const p of this.players.values()) if (p.loc === locId && !p.dead) out.push(p);
    return out;
  }

  /* ---------------- 加入 / 离开 ---------------- */
  join(conn, name, token) {
    let player = null;
    if (token && this.players.has(token)) {
      player = this.players.get(token);
      player.dead = player.dead || false;
    }
    if (!player) {
      const id = 'p' + uid(9);
      player = C.createCharacter(name, id);
      player.loc = START_LOC;
      player.invites = [];
      this.players.set(id, player);
    }
    player.lastSeen = Date.now();
    player.conn = null;
    this.conns.set(player.id, conn);
    conn.playerId = player.id;

    this.log(player.id, [
      `${player.name}，你睁开眼。`,
      '天光从塌了半边的楼顶漏下来，落在一地碎玻璃上。你躺在一辆翻倒的轿车旁边，喉咙干得像塞了砂纸，身上每一块肌肉都在疼。',
      '你不记得自己是怎么到这里来的。你只记得，外面已经不是人的世界了。',
    ]);
    this.log(player.id, [
      `【${this.locName(player.loc)}】`,
      LOCATIONS[player.loc].desc,
    ]);
    this.feed(`${player.name} 出现在 ${this.locName(player.loc)}。`);
    this.pushView(player.id);
    this.broadcastPresence();
    this.save(true);
    return player;
  }

  leave(id) {
    const ch = this.players.get(id);
    if (!ch) return;
    ch.lastSeen = Date.now();
    this.conns.delete(id);
    this.feed(`${ch.name} 下线了，身影消失在废墟之间。`);
    this.broadcastPresence();
    this.save(true);
  }

  /* ---------------- 主循环 ---------------- */
  tick() {
    const w = this.world;
    w.clockMin += 2;
    this.tickCount++;
    const h = this.hour;

    // 天气
    if (w.clockMin > w.weatherUntil) {
      const options = ['clear', 'clear', 'cloudy', 'cloudy', 'rain', 'rain', 'fog', 'sandstorm'];
      const next = pick(options);
      if (next !== w.weather) {
        w.weather = next;
        w.weatherUntil = w.clockMin + rint(120, 300);
        const info = WEATHER[next];
        this.feed(`天色变了：${info.name}。${info.desc}`);
        for (const p of this.players.values()) {
          if (!p.dead) this.send(p.id, { t: 'weather', weather: next, text: info.desc });
        }
      } else {
        w.weatherUntil = w.clockMin + rint(120, 300);
      }
    }

    // 容器刷新
    if (w.clockMin - (w.lastRefresh || 0) > 480) {
      w.lastRefresh = w.clockMin;
      for (const id of Object.keys(LOCATIONS)) {
        for (const c of LOCATIONS[id].containers) {
          const st = w.containers[id] && w.containers[id][c.key];
          if (st && st.left < c.cap && chance(0.7)) st.left += 1;
        }
      }
      this.feed('附近某些地方，似乎又被人翻找过一遍。');
    }

    // NPC
    NPC.npcTick(this);

    // 玩家状态
    for (const p of this.players.values()) {
      if (p.dead) continue;
      const hide = p.hideout && p.hideout.loc === p.loc;
      const partySize = p.party ? this.partyMembers(p.party).length : 0;
      const logs = C.tickCharacter(p, 2 / 60, {
        night: this.isNight,
        shelter: hide && p.hideout.buildings.shelter,
        rain: w.weather === 'rain',
        party: partySize > 1,
      });
      if (logs.length) this.log(p.id, logs, 'status');

      if (p.mutating) {
        this.killPlayer(p, '感染值达到 100，病毒越过了最后的界限。你的手指一根根僵直，视野变成一片浑浊的红色。');
        continue;
      }
      if (p.hp <= 0) {
        this.killPlayer(p, '你的膝盖先着地，然后整个人倒下去。地面的凉意贴着脸，声音越来越远。');
        continue;
      }

      // 精神崩溃
      if (p.sanity < 25 && chance(0.012) && p.combat == null) {
        const exits = Object.keys(locDef(p.loc).exits || {});
        if (exits.length) {
          const to = pick(exits);
          p.loc = to;
          p.flags.rest = false;
          this.log(p.id, ['你突然听不见自己的呼吸了。', '胸口像被一只湿冷的手攥住——你开始跑，不知道往哪里跑，只是想离开这里。等你停下来，已经站在另一个地方。'], 'status');
          this.pushView(p.id);
        }
      }
      // 幻觉
      if (p.sanity < 18 && chance(0.02)) {
        this.log(p.id, [pick([
          '你听见有人在叫你的名字，声音很轻，从背后传来。你回头，什么也没有。',
          '墙上的影子动了。它没有跟着你的动作动。',
          '你看见远处的窗边站着一个孩子，穿着校服。你眨了一下眼，那里只有一扇破窗。',
          '有人在耳边说话，你听不清词，只能分辨出那是一种很耐心的语气。',
        ])], 'halluc');
      }
      // 精神过低时体力恢复变慢
      if (p.sanity < 20) p.stamina = Math.max(0, p.stamina - 0.1);

      // 体力耗尽
      if (p.stamina <= 0 && chance(0.004)) {
        this.log(p.id, ['你的腿突然一软，整个人靠在了墙上。', '再这么耗下去，你会倒在这条街上。'], 'status');
        p.pain = clamp(p.pain + 2, 0, 100);
      }
    }

    // 传闻
    if (w.clockMin > (w.rumorAt || 0)) {
      this.newRumor();
    }

    // 夜袭据点
    this.checkRaid(h);

    // 环境事件
    if (chance(0.012)) {
      const text = pick(AMBIENT);
      this.feed(text);
    }

    if (this.tickCount % 3 === 0) {
      this.pushAllViews();
    }
    if (this.tickCount % 30 === 0) this.save();
  }

  /* ---------------- 视图 ---------------- */
  invView(p) {
    return p.inv.map((s, i) => {
      const def = itemDef(s.id);
      return {
        i, id: s.id, name: def.name, qty: s.qty, type: def.type,
        w: Math.round(def.w * s.qty * 100) / 100, eq: s.eq,
        dec: s.dec != null ? Math.round(s.dec) : null,
        desc: def.desc,
      };
    });
  }

  view(p) {
    const d = C.derived(p);
    const loc = locDef(p.loc);
    const w = this.world;
    const exits = Object.keys(loc.exits || {}).map(to => ({
      id: to, name: LOCATIONS[to].name, cost: loc.exits[to], danger: LOCATIONS[to].danger,
    }));
    const special = (w.specialContainers && w.specialContainers[p.loc]) || [];
    const containers = loc.containers.concat(special).map(c => ({
      key: c.key, name: c.name, left: (w.containers[p.loc] && w.containers[p.loc][c.key] ? w.containers[p.loc][c.key].left : 0),
    }));
    const npcs = w.npcs.filter(n => n.alive && n.loc === p.loc).map(n => ({
      id: n.id, name: n.name, kind: n.kind, desc: n.desc,
      questReady: !!(n.quest && !n.quest.claimed && n.quest.claimable),
      quest: n.quest ? { title: n.quest.title, desc: n.quest.desc, need: `${itemDef(n.quest.item).name} ×${n.quest.qty}`, reward: itemDef(n.quest.reward).name, claimable: n.quest.claimable, claimed: n.quest.claimed } : null,
      stock: n.stock.filter(s => s.qty > 0).map(s => ({ id: s.id, name: itemDef(s.id).name, price: s.price })),
    }));
    const others = this.playersInLoc(p.loc).filter(o => o !== p && o.id !== p.id).map(o => ({
      id: o.id, name: o.name, party: o.party === p.party && !!p.party, hp: Math.round(o.hp),
    }));
    const partyMembers = p.party ? this.partyMembers(p.party).map(m => ({
      id: m.id, name: m.name, hp: Math.round(m.hp), loc: this.locName(m.loc), lead: m.party === m.id,
    })) : [];
    const ground = (w.ground[p.loc] || []).map((g, i) => ({ i, name: itemDef(g.id).name, qty: g.qty, id: g.id }));
    const corpses = (w.corpses[p.loc] || []).map((c, i) => ({ i, name: c.name, left: c.stock.length }));

    const combat = p.combat ? {
      round: p.combat.round,
      sneak: p.combat.sneak,
      human: p.combat.human,
      aimed: p.combat.aimed,
      enemies: p.combat.enemies.map((e, i) => ({
        i, name: e.name, hp: Math.max(0, Math.round(e.hp)), maxHp: e.maxHp,
        desc: e.desc, dead: e.hp <= 0,
        disarmed: !!e.disarmed,
      })),
      canStealth: p.combat.sneak,
      hasMolotov: C.countItem(p, 'molotov') > 0,
    } : null;

    const buildings = Object.keys(p.hideout.buildings || {});
    return {
      t: 'view',
      me: {
        id: p.id, name: p.name, level: p.level, xp: Math.round(p.xp),
        xpNeed: 80 + 40 * (p.level - 1), points: p.points,
        hp: Math.round(p.hp), hpMax: d.hpMax,
        hunger: Math.round(p.hunger), thirst: Math.round(p.thirst),
        stamina: Math.round(p.stamina), staminaMax: d.staminaMax,
        infection: Math.round(p.infection * 10) / 10, pain: Math.round(p.pain),
        sanity: Math.round(p.sanity),
        load: d.load, cap: d.cap,
        attrs: p.attrs, skills: p.skills,
        injuries: p.injuries.map(i => ({ type: i.type, name: C.INJURY_NAMES[i.type] || i.type, sev: Math.round(i.sev), bleed: i.bleed })),
        weapon: itemDef(d.weapon).name, armor: d.armor,
        resting: p.flags.rest, flashlight: p.flags.flashlight,
        dead: !!p.dead, karma: p.karma || 0,
        kills: p.stats.kills,
      },
      loc: {
        id: p.loc, name: loc.name, desc: loc.desc, danger: loc.danger,
        safe: !!loc.safe, exits, containers, npcs, others, ground, corpses,
        forage: !!loc.forage,
        hideoutHere: p.hideout.loc === p.loc,
        isHideout: p.hideout.loc === p.loc,
      },
      hideout: {
        loc: p.hideout.loc, locName: p.hideout.loc ? this.locName(p.hideout.loc) : null,
        buildings, storageCount: p.hideout.storage.length,
        traps: p.hideout.buildings.trap ? 1 : 0,
        storage: p.hideout.storage.map((s, i) => ({ i, id: s.id, name: itemDef(s.id).name, qty: s.qty })),
      },
      world: {
        time: this.timeStr(), day: this.day, hour: this.hour, night: this.isNight,
        weather: w.weather, weatherName: this.weatherInfo().name,
        feed: w.feed.slice(0, 12),
        rumor: w.rumors[0] || null,
        online: this.conns.size,
        room: this.code,
      },
      inv: this.invView(p),
      party: { members: partyMembers, invites: (p.invites || []).length },
      combat,
      recipes: RECIPES.map(r => ({ id: r.id, name: r.name, need: r.need, out: Object.keys(r.out).map(k => itemDef(k).name).join('、'), desc: r.desc, time: r.time })),
      campfireRecipes: CAMPFIRE_RECIPES.map(r => ({ id: r.id, name: r.name, need: r.need, desc: r.desc })),
      buildOptions: Object.keys(BUILDINGS).map(k => ({ id: k, name: BUILDINGS[k].name, need: BUILDINGS[k].need, desc: BUILDINGS[k].desc, built: !!p.hideout.buildings[k] })),
    };
  }

  pushView(id) {
    const p = this.players.get(id);
    if (!p) return;
    this.send(id, this.view(p));
  }
  pushAllViews() {
    for (const p of this.players.values()) {
      if (this.conns.has(p.id)) this.send(p.id, this.view(p));
    }
  }
  broadcastPresence() {
    this.pushAllViews();
  }

  partyMembers(partyId) {
    const out = [];
    for (const p of this.players.values()) {
      if (p.party === partyId && !p.dead) out.push(p);
    }
    return out;
  }

  addNoise(locId, amount) {
    this.world.noise[locId] = (this.world.noise[locId] || 0) + amount;
  }
  takeNoise(locId, amount) {
    const v = Math.max(0, (this.world.noise[locId] || 0) - amount);
    this.world.noise[locId] = v;
    return v;
  }

  /* ---------------- 行动分发 ---------------- */
  handle(p, msg) {
    if (!p || !this.players.has(p.id)) return;
    if (p.dead && !['revive', 'delete_char'].includes(msg.a)) {
      this.send(p.id, { t: 'err', msg: '你已经死了。' });
      return;
    }
    if (Date.now() - (p.lastAction || 0) < 700) return;
    p.lastAction = Date.now();
    if (p.combat && !['combat', 'chat', 'look', 'revive', 'delete_char'].includes(msg.a)) {
      this.send(p.id, { t: 'err', msg: '你正在交战中，先解决眼前的敌人（或逃跑）。' });
      return;
    }
    p.lastSeen = Date.now();

    try {
      switch (msg.a) {
        case 'look': return this.doLook(p);
        case 'search': return this.doSearch(p, msg.key);
        case 'forage': return this.doForage(p);
        case 'move': return this.doMove(p, msg.to);
        case 'rest': return this.doRest(p);
        case 'use': return this.doUse(p, msg.item);
        case 'equip': return this.doEquip(p, msg.item);
        case 'drop': return this.doDrop(p, msg.item, msg.qty);
        case 'craft': return this.doCraft(p, msg.recipe);
        case 'campfire': return this.doCampfire(p, msg.recipe);
        case 'build': return this.doBuild(p, msg.building);
        case 'set_hideout': return this.doSetHideout(p);
        case 'store': return this.doStore(p, msg.item, msg.qty);
        case 'take': return this.doTake(p, msg.item, msg.qty);
        case 'attribute': return this.doAttribute(p, msg.attr);
        case 'talk': return this.doTalk(p, msg.npc);
        case 'trade': return this.doTrade(p, msg);
        case 'quest': return this.doQuest(p, msg.npc);
        case 'attack_npc': return this.doAttackNpc(p, msg.npc);
        case 'chase_rumor': return this.doChaseRumor(p);
        case 'chat': return this.doChat(p, msg);
        case 'party': return this.doParty(p, msg);
        case 'pvp': return this.doPvp(p, msg);
        case 'combat': return this.doCombat(p, msg);
        case 'give': return this.doGive(p, msg);
        case 'pickup': return this.doPickup(p, msg.idx);
        case 'search_corpse': return this.doSearchCorpse(p, msg.idx);
        case 'revive': return this.doRevive(p);
        case 'delete_char': return this.doDelete(p);
        default: return this.send(p.id, { t: 'err', msg: '未知的行动。' });
      }
    } catch (e) {
      console.error('行动处理出错', msg.a, e);
      this.send(p.id, { t: 'err', msg: '服务端处理这个动作时出了点问题，换个动作试试。' });
    }
  }

  /* ---------------- 探索 ---------------- */
  doLook(p) {
    const loc = locDef(p.loc);
    const lines = [`【${loc.name}】`, loc.desc];
    lines.push(pick(loc.flavor || ['四周很安静，安静得能听见自己的心跳。']));
    const w = this.world;
    if (this.isNight) lines.push('夜色把所有轮廓都磨圆了，你看不清十米以外的东西。');
    if (w.weather === 'fog') lines.push('雾把声音也一起吞掉了，你只听见自己鞋底的摩擦。');
    const conts = loc.containers.map(c => {
      const st = w.containers[p.loc] && w.containers[p.loc][c.key];
      const left = st ? st.left : 0;
      return `${c.name}（${left > 0 ? '也许还有东西' : '已经被翻空了'}）`;
    });
    lines.push(`可以翻找：${conts.join('、')}。`);
    const exits = Object.keys(loc.exits).map(t => `${LOCATIONS[t].name}（${loc.exits[t]} 分钟）`);
    lines.push(`可以前往：${exits.join('、')}。`);
    const np = w.npcs.filter(n => n.alive && n.loc === p.loc);
    if (np.length) lines.push(`这里有人：${np.map(n => n.name).join('、')}。`);
    const others = this.playersInLoc(p.loc).filter(o => o.id !== p.id);
    if (others.length) lines.push(`你看见 ${others.map(o => o.name).join('、')} 也在这里。`);
    this.log(p.id, lines);
    this.pushView(p.id);
  }

  doSearch(p, key) {
    const loc = locDef(p.loc);
    const special = (this.world.specialContainers && this.world.specialContainers[loc.id]) || [];
    const cont = loc.containers.concat(special).find(c => c.key === key);
    if (!cont) return this.send(p.id, { t: 'err', msg: '这里没有那个地方可以翻。' });
    const st = this.world.containers[p.loc][key];
    if (!st || st.left <= 0) {
      this.log(p.id, [`${cont.name} 里只剩下一些没用的东西。你再翻了两下，指头被划了道小口子，什么也没找到。`]);
      return this.pushView(p.id);
    }
    if (p.stamina < 6) {
      this.log(p.id, ['你的手抖得厉害，连抽屉都拉不开。你需要休息一会儿。']);
      return this.pushView(p.id);
    }
    st.left -= 1;
    p.stamina -= 8;
    p.stats.searches += 1;
    this.addNoise(p.loc, 1);
    const d = C.derived(p);
    const count = 1 + (loc.danger >= 3 ? 1 : 0) + (chance(0.35) ? 1 : 0) + (p.skills.scout >= 4 ? 1 : 0);
    const loot = CB.rollLoot(cont.loot, loc.danger, count);
    const lines = [];
    const flavorSearch = [
      `你蹲下来，把 ${cont.name} 拉开一条缝。灰尘扑在脸上，里面有一股封闭很久的味道。`,
      `你用手肘顶开 ${cont.name}，金属摩擦声在空处很响。`,
      `你在 ${cont.name} 里摸索，指尖碰到东西的轮廓。`,
    ];
    lines.push(pick(flavorSearch));
    const found = [];
    for (const l of loot) {
      if (chance(0.18)) continue;
      C.addItem(p, l.id, l.qty);
      found.push(`${itemDef(l.id).name} ×${l.qty}`);
    }
    if (found.length) {
      lines.push(`你摸出了：${found.join('、')}。`);
      lines.push(chance(0.25) ? '有东西在袋子底部硌了你一下，你把它塞进了背包。' : '你把它们塞进背包，心跳得快了些。');
      C.gainXp(p, 4 + loc.danger * 2);
      this.addNoise(p.loc, 1);
    } else {
      lines.push('里面只剩下碎玻璃、灰尘，和一堆被雨泡烂的纸。');
    }
    C.trainSkill(p, 'scout', 1);
    this.log(p.id, lines);

    // 搜索后遭遇判定
    const ec = CB.encounterChance(loc, this.world, p, this.takeNoise(p.loc, 1));
    if (chance(ec)) this.triggerEncounter(p, 'search');
    else this.pushView(p.id);
  }

  doForage(p) {
    const loc = locDef(p.loc);
    if (!loc.forage) {
      this.log(p.id, ['这里没有可以采集的东西。']);
      return this.pushView(p.id);
    }
    if (p.stamina < 6) {
      this.log(p.id, ['你累得直不起腰，先歇一会儿吧。']);
      return this.pushView(p.id);
    }
    p.stamina -= 6;
    this.addNoise(p.loc, 1);
    const loot = CB.rollLoot(loc.forage.table, Math.max(1, loc.danger - 1), rint(1, loc.forage.max));
    const found = [];
    for (const l of loot) {
      if (chance(0.2)) continue;
      C.addItem(p, l.id, l.qty);
      found.push(`${itemDef(l.id).name} ×${l.qty}`);
    }
    const flavorByType = {
      urban: ['你蹲在角落里扒开瓦砾，尘土呛得你直咳。', '你沿着墙根走了一圈，把能带走的东西都挑出来。'],
      forest: ['你在草丛里翻找，手掌被带刺的枝条划了一下。', '你拨开落叶，腐殖土的气味冲上来。'],
      farm: ['你在田埂和堆肥堆之间翻找，鞋底陷进湿泥里。', '你掀开一块塑料布，下面藏着些还能用的东西。'],
      warehouse: ['你在货架底下和托盘缝隙里摸，指尖沾满灰。', '你踢开一堆压扁的纸箱，看下面有没有东西。'],
      medical: ['你在推车底下和垃圾桶边翻找，消毒水味呛得皱眉。', '你打开一个没被翻过的柜子，里面还有点东西。'],
      school: ['你翻遍了器材室和储物柜的底层。', '你把讲台抽屉全拉了出来。'],
      road: ['你沿着护栏翻找，脚边全是碎玻璃。', '你打开一个被撞开的后备箱，里面还有东西。'],
      water: ['你在渔市的湿地上翻找，鞋底黏着鱼鳞。', '你把泡沫箱一只只掀开。'],
      underground: ['你在应急箱和检修格里摸索。', '你沿着墙根摸了一圈，摸到几个硬的东西。'],
      shelter: ['你在发放点的杂物堆里翻找。', '你把空铺位底下的抽屉全拉出来。'],
      military: ['你在弹坑边和废弃装备堆里翻找。', '你拉开一个被打穿的背包，里面还有东西。'],
      police: ['你在证物架和值班台下翻找。', '你掀开一块防弹毯，下面压着些东西。'],
    };
    const lines = [pick(flavorByType[loc.type] || flavorByType.urban)];
    lines.push(found.length ? `你找到：${found.join('、')}。` : '除了碎瓦和干枯的草，什么也没有。');
    C.gainXp(p, 3);
    this.log(p.id, lines);
    this.pushView(p.id);
  }

  doPickup(p, idx) {
    const ground = this.world.ground[p.loc] || [];
    const g = ground[idx];
    if (!g) return this.pushView(p.id);
    C.addItem(p, g.id, g.qty);
    ground.splice(idx, 1);
    this.log(p.id, [`你捡起了 ${itemDef(g.id).name} ×${g.qty}。`]);
    this.pushView(p.id);
  }

  doSearchCorpse(p, idx) {
    const list = this.world.corpses[p.loc] || [];
    const corpse = list[idx];
    if (!corpse) return this.pushView(p.id);
    if (!corpse.stock.length) {
      this.log(p.id, ['尸体已经被搜刮干净了，只剩下一堆分不清是谁的衣服。']);
      return this.pushView(p.id);
    }
    const taken = [];
    const items = corpse.stock.splice(0, 3);
    for (const it of items) {
      C.addItem(p, it.id, it.qty);
      taken.push(`${itemDef(it.id).name} ×${it.qty}`);
    }
    const lines = [`你蹲在 ${corpse.name} 的尸体旁边，把手伸进他的外套内袋。`];
    lines.push(`你摸出：${taken.join('、')}。`);
    if (chance(0.3)) lines.push('他的眼睛还睁着，你伸手把它合上了。');
    this.log(p.id, lines);
    this.pushView(p.id);
  }

  /* ---------------- 移动 ---------------- */
  doMove(p, to) {
    const loc = locDef(p.loc);
    if (!loc.exits[to]) return this.send(p.id, { t: 'err', msg: '那个方向走不过去。' });
    if (p.combat) return this.send(p.id, { t: 'err', msg: '你正在交战，跑不掉也走不了。' });
    const cost = loc.exits[to];
    const stamCost = Math.round(4 + cost * 0.5);
    if (p.stamina < stamCost) {
      this.log(p.id, ['你的腿已经不听使唤了，再走这么远会倒在半路。先找个地方歇一歇。']);
      return this.pushView(p.id);
    }
    p.stamina -= stamCost;
    p.flags.rest = false;
    p.stats.distance += cost;
    const from = p.loc;
    p.loc = to;
    C.gainXp(p, 2);
    const lines = [`你沿着 ${cost} 分钟的路，从 ${this.locName(from)} 走向 ${this.locName(to)}。`];
    const travel = [
      '路上你贴着墙走，尽量避开空旷的地方。',
      '你经过一段被烧过的街区，焦味还没散干净。',
      '中途你停了两次，蹲在车后面听周围的动静。',
      '有一段路你几乎是跑过去的，因为身后传来了拖行的声音。',
      '你把背包换到另一边肩上，肩膀已经勒出一道红印。',
    ];
    lines.push(pick(travel));
    lines.push(`【${this.locName(to)}】`);
    lines.push(LOCATIONS[to].desc);
    this.log(p.id, lines);
    this.feed(`${p.name} 从 ${this.locName(from)} 前往 ${this.locName(to)}。`);
    const ec = CB.encounterChance(LOCATIONS[to], this.world, p, 1);
    if (chance(ec + 0.06)) this.triggerEncounter(p, 'travel');
    else this.pushView(p.id);
  }

  doRest(p) {
    if (p.combat) return this.send(p.id, { t: 'err', msg: '现在没空休息。' });
    p.flags.rest = !p.flags.rest;
    if (p.flags.rest) {
      this.log(p.id, ['你在墙根坐下，把背贴着水泥。', '闭上眼之前，你先听了一会儿周围的动静——没有脚步声，没有拖行声。', '你决定歇一会儿。体力会慢慢恢复。']);
      // 休息时遭遇概率降低但也存在
      if (chance(CB.encounterChance(locDef(p.loc), this.world, p, 0) * 0.6)) {
        p.flags.rest = false;
        this.triggerEncounter(p, 'rest');
        return;
      }
    } else {
      this.log(p.id, ['你站起来，活动了一下发麻的腿。']);
    }
    this.pushView(p.id);
  }

  /* ---------------- 物品 ---------------- */
  doUse(p, item) {
    if (p.combat) return this.send(p.id, { t: 'err', msg: '战斗中请用战斗面板处理。' });
    const res = C.useItem(p, item, this);
    this.log(p.id, res.msg.split('\n'), res.ok ? 'narr' : 'warn');
    this.pushView(p.id);
  }

  doEquip(p, item) {
    const res = C.equip(p, item);
    this.log(p.id, [res.msg], res.ok ? 'narr' : 'warn');
    this.pushView(p.id);
  }

  doDrop(p, item, qty = 1) {
    if (!C.countItem(p, item)) return this.send(p.id, { t: 'err', msg: '你身上没有这件东西。' });
    const q = Math.min(qty, C.countItem(p, item));
    C.removeItem(p, item, q);
    if (!this.world.ground[p.loc]) this.world.ground[p.loc] = [];
    const slot = this.world.ground[p.loc].find(g => g.id === item);
    if (slot) slot.qty += q;
    else this.world.ground[p.loc].push({ id: item, qty: q });
    this.log(p.id, [`你把 ${itemDef(item).name} ×${q} 放在地上。`]);
    this.pushView(p.id);
  }

  /* ---------------- 制作 ---------------- */
  canCraft(p, need) {
    return Object.entries(need).every(([id, q]) => C.countItem(p, id) >= q);
  }

  doCraft(p, recipeId) {
    const r = RECIPES.find(x => x.id === recipeId);
    if (!r) return this.send(p.id, { t: 'err', msg: '没有这个配方。' });
    if (!this.canCraft(p, r.need)) {
      return this.log(p.id, [`材料不够。需要：${Object.entries(r.need).map(([id, q]) => `${itemDef(id).name}×${q}`).join('、')}。`], 'warn');
    }
    if (p.stamina < 10) return this.log(p.id, ['你手抖得连工具都握不稳，先休息一下。'], 'warn');
    for (const [id, q] of Object.entries(r.need)) C.removeItem(p, id, q);
    p.stamina -= 10;
    const bonus = p.skills.forge >= 5 && chance(0.35);
    for (const [id, q] of Object.entries(r.out)) C.addItem(p, id, q + (bonus ? 1 : 0));
    const outNames = Object.entries(r.out).map(([id, q]) => `${itemDef(id).name}×${q + (bonus ? 1 : 0)}`).join('、');
    this.log(p.id, [
      `你找了个背风的角落蹲下来，把东西一件件摊在地上。`,
      r.desc,
      `半小时后，你手上多了：${outNames}。`,
      bonus ? '这次做得比预想的好，多出了一件。' : '',
    ].filter(Boolean));
    C.gainXp(p, 8);
    if (C.trainSkill(p, r.skill, 1)) this.log(p.id, [`你的「${C.skillName(r.skill)}」熟练了一些。`], 'status');
    p.stats.crafted += 1;
    this.pushView(p.id);
  }

  doCampfire(p, recipeId) {
    if (!p.hideout.buildings.campfire) return this.log(p.id, ['你需要先在据点搭一个篝火。'], 'warn');
    const r = CAMPFIRE_RECIPES.find(x => x.id === recipeId);
    if (!r) return this.send(p.id, { t: 'err', msg: '没有这个做法。' });
    if (!this.canCraft(p, r.need)) return this.log(p.id, ['材料不够。'], 'warn');
    for (const [id, q] of Object.entries(r.need)) C.removeItem(p, id, q);
    for (const [id, q] of Object.entries(r.out)) C.addItem(p, id, q);
    this.log(p.id, ['你蹲在火边，火苗舔着容器底部。', r.desc, `你得到了 ${Object.entries(r.out).map(([id, q]) => `${itemDef(id).name}×${q}`).join('、')}。`]);
    this.pushView(p.id);
  }

  doBuild(p, key) {
    const b = BUILDINGS[key];
    if (!b) return this.send(p.id, { t: 'err', msg: '没有这个建筑。' });
    if (!p.hideout.loc) return this.log(p.id, ['你还没有确定据点。先在这里「设为据点」。'], 'warn');
    if (p.loc !== p.hideout.loc) return this.log(p.id, ['你必须在自己的据点里才能建造。'], 'warn');
    if (p.hideout.buildings[key]) return this.log(p.id, ['这个已经建好了。'], 'warn');
    if (!this.canCraft(p, b.need)) {
      return this.log(p.id, [`材料不够。需要：${Object.entries(b.need).map(([id, q]) => `${itemDef(id).name}×${q}`).join('、')}。`], 'warn');
    }
    for (const [id, q] of Object.entries(b.need)) C.removeItem(p, id, q);
    p.hideout.buildings[key] = true;
    this.log(p.id, [`你花了一个多小时，把 ${b.name} 搭了起来。`, b.desc, '据点又结实了一点。']);
    this.feed(`${p.name} 在 ${this.locName(p.loc)} 建起了 ${b.name}。`);
    C.gainXp(p, 15);
    this.pushView(p.id);
  }

  doSetHideout(p) {
    if (locDef(p.loc).safe && p.loc === 'bihansuo') {
      return this.log(p.id, ['避难所里已经有主了。你不能在这里安家。'], 'warn');
    }
    if (p.hideout.loc === p.loc) return this.log(p.id, ['这里已经是你的据点了。'], 'warn');
    p.hideout.loc = p.loc;
    this.log(p.id, [
      `你决定在这里安家——${this.locName(p.loc)}。`,
      '你把能用上的东西搬到背风的角落，记下了退路和视野死角。',
      '从现在起，这里就是你的据点。你可以在这里建造、存放物资、设置陷阱。',
    ]);
    this.feed(`${p.name} 把 ${this.locName(p.loc)} 设为据点。`);
    this.pushView(p.id);
  }

  doStore(p, item, qty = 1) {
    if (!p.hideout.loc || p.loc !== p.hideout.loc) return this.log(p.id, ['你必须在据点里才能存取物资。'], 'warn');
    if (!p.hideout.buildings.storage && p.hideout.storage.length > 20) {
      return this.log(p.id, ['没有储物柜，东西堆在地上容易丢。先建一个储物柜吧。'], 'warn');
    }
    if (!C.countItem(p, item)) return this.send(p.id, { t: 'err', msg: '你身上没有这件东西。' });
    const q = Math.min(qty, C.countItem(p, item));
    C.removeItem(p, item, q);
    const slot = p.hideout.storage.find(s => s.id === item);
    if (slot) slot.qty += q;
    else p.hideout.storage.push({ id: item, qty: q });
    this.log(p.id, [`你把 ${itemDef(item).name} ×${q} 放进据点的储物处。`]);
    this.pushView(p.id);
  }

  doTake(p, item, qty = 1) {
    if (!p.hideout.loc || p.loc !== p.hideout.loc) return this.log(p.id, ['你必须在据点里才能存取物资。'], 'warn');
    const slot = p.hideout.storage.find(s => s.id === item);
    if (!slot) return this.send(p.id, { t: 'err', msg: '据点里没有这件东西。' });
    const q = Math.min(qty, slot.qty);
    slot.qty -= q;
    p.hideout.storage = p.hideout.storage.filter(s => s.qty > 0);
    C.addItem(p, item, q);
    this.log(p.id, [`你从储物处取出 ${itemDef(item).name} ×${q}。`]);
    this.pushView(p.id);
  }

  doAttribute(p, attr) {
    if (p.points <= 0) return this.send(p.id, { t: 'err', msg: '你没有可分配的点数。' });
    if (!['str', 'agi', 'con', 'per'].includes(attr)) return this.send(p.id, { t: 'err', msg: '没有这个属性。' });
    p.points -= 1;
    p.attrs[attr] += 1;
    const names = { str: '力量', agi: '敏捷', con: '体质', per: '感知' };
    this.log(p.id, [`你把一点属性加到了「${names[attr]}」上（现在 ${p.attrs[attr]}）。`]);
    if (attr === 'con') p.hp = Math.min(p.hp + 6, C.derived(p).hpMax);
    this.pushView(p.id);
  }

  /* ---------------- NPC ---------------- */
  npcAt(p, npcId) {
    return this.world.npcs.find(n => n.id === npcId && n.alive && n.loc === p.loc);
  }

  doTalk(p, npcId) {
    const npc = this.npcAt(p, npcId);
    if (!npc) return this.send(p.id, { t: 'err', msg: '这里没有这个人。' });
    const res = NPC.talk(p, npc, this);
    this.log(p.id, res.lines);
    if (res.startCombat) {
      this.startNpcCombat(p, npc);
      return;
    }
    if (npc.quest && !npc.quest.claimed) {
      const q = npc.quest;
      this.log(p.id, [`〔委托〕${q.title}：${q.desc} 需要 ${itemDef(q.item).name} ×${q.qty}，报酬 ${itemDef(q.reward).name}。`], 'status');
      const chk = NPC.checkQuest(p, npc);
      if (chk && chk.ready) this.log(p.id, [chk.msg], 'status');
    }
    this.pushView(p.id);
  }

  doTrade(p, msg) {
    const npc = this.npcAt(p, msg.npc);
    if (!npc) return this.send(p.id, { t: 'err', msg: '这里没有这个人。' });
    const res = NPC.trade(p, npc, msg.takeIdx, msg.giveId, msg.giveQty || 1);
    this.log(p.id, res.msg.split('\n'), res.ok ? 'narr' : 'warn');
    this.pushView(p.id);
  }

  doQuest(p, npcId) {
    const npc = this.npcAt(p, npcId);
    if (!npc) return this.send(p.id, { t: 'err', msg: '这里没有这个人。' });
    if (!npc.quest) return this.log(p.id, [`${npc.name} 摆摆手："现在没什么要你帮忙的。"`], 'warn');
    const res = NPC.completeQuest(p, npc);
    this.log(p.id, res.msg.split('\n'), res.ok ? 'narr' : 'warn');
    if (res.ok) {
      C.gainXp(p, 25);
      this.feed(`${p.name} 完成了 ${npc.name} 的委托。`);
    }
    this.pushView(p.id);
  }

  doAttackNpc(p, npcId) {
    const npc = this.npcAt(p, npcId);
    if (!npc) return this.send(p.id, { t: 'err', msg: '这里没有这个人。' });
    const kindMap = { raider: 'raider', trader: 'scavenger', medic: 'scavenger', orderly: 'orderly', scavenger: 'scavenger' };
    const type = kindMap[npc.kind] || 'scavenger';
    const def = ENEMIES[type];
    this.log(p.id, [
      `你把 ${itemDef(C.derived(p).weapon).name} 抬起来，对准了 ${npc.name}。`,
      `${npc.name} 的反应比你想象的快：${npc.kind === 'orderly' ? '他立刻退到掩体后面，枪口抬起。' : '他往旁边一滚，手里的东西已经举起来了。'}`,
    ]);
    p.combat = {
      enemies: [{ uid: 'npc:' + npc.id, type, name: npc.name, hp: npc.hp, maxHp: 80, desc: npc.desc }],
      round: 1, sneak: chance(0.5), aimed: 0, human: true, startAt: Date.now(), looted: false, npcId: npc.id,
    };
    this.feed(`${p.name} 在 ${this.locName(p.loc)} 向 ${npc.name} 动手了。`);
    this.pushView(p.id);
  }

  startNpcCombat(p, npc) {
    const type = npc.kind === 'raider' ? 'raider' : npc.kind === 'orderly' ? 'orderly' : 'scavenger';
    const def = ENEMIES[type];
    p.combat = {
      enemies: [{ uid: 'npc:' + npc.id, type, name: npc.name, hp: npc.hp, maxHp: 80, desc: npc.desc }],
      round: 1, sneak: false, aimed: 0, human: true, startAt: Date.now(), looted: false, npcId: npc.id,
    };
    this.pushView(p.id);
  }

  /* ---------------- 战斗 ---------------- */
  triggerEncounter(p, cause) {
    const loc = locDef(p.loc);
    const enemies = CB.makeEnemies(loc.type);
    const sneak = p.skills.stealth >= 3 && chance(0.3 + p.skills.stealth * 0.05);
    const intro = [];
    if (cause === 'search') intro.push('你正把手伸进货架深处，身后传来一声很轻的、像是湿布拖过地面的声音。');
    else if (cause === 'travel') intro.push('转过街角，你差点撞上它们。');
    else if (cause === 'rest') intro.push('你刚闭上眼睛，就听见了脚步。');
    else if (cause === 'noise') intro.push('声音把你招来的东西到了。');
    if (!sneak) {
      intro.push(enemies.length > 1
        ? `一共有 ${enemies.length} 个。它们同时转过头，空着的眼眶对着你。`
        : `${enemies[0].desc}`);
    } else {
      intro.push('它们还没发现你。你可以贴上去先下手——或者悄悄退开。');
    }
    intro.push(`【遭遇：${enemies.map(e => e.name).join('、')}】`);
    CB.startCombat(p, enemies, { sneak, lines: intro });
    this.log(p.id, intro, 'combat');
    this.send(p.id, { t: 'alert', text: '遭遇战' });
    this.pushView(p.id);
  }

  doCombat(p, msg) {
    if (!p.combat) return this.pushView(p.id);
    const c = p.combat;
    const act = msg.act;
    if (act === 'use') {
      const res = C.useItem(p, msg.item, this);
      this.log(p.id, res.msg.split('\n'), res.ok ? 'narr' : 'warn');
      // 使用物品也消耗一回合：让敌人行动
      const r = CB.combatAction(this, p, 'use', msg.target || 0);
      this.log(p.id, r.lines);
      if (r.ended) this.afterCombat(p, r);
      this.pushView(p.id);
      return;
    }
    const r = CB.combatAction(this, p, act, msg.target || 0);
    this.log(p.id, r.lines, 'combat');
    if (r.ended) this.afterCombat(p, r);
    this.pushView(p.id);
  }

  afterCombat(p, r) {
    const c = p.combat;
    if (!c) return;
    if (r.victory) {
      const enemies = c.enemies;
      const xp = CB.xpForEnemies(enemies);
      C.gainXp(p, xp);
      const lines = ['最后一个倒下的时候，四周突然安静下来。', '你站在原地，听见自己的心跳，一下一下，很响。'];
      if (enemies.some(e => e.type === 'brood' || e.type === 'brute')) lines.push('空气里充满了腐臭，你退后两步，胃里一阵翻搅。');
      // 自动搜刮
      const loc = locDef(p.loc);
      let found = [];
      for (const e of enemies) {
        if (e.type.startsWith('npc')) continue;
        const def = ENEMIES[e.type];
        if (chance(0.55)) {
          const loot = CB.rollLoot(def.loot, loc.danger, 1);
          for (const l of loot) {
            C.addItem(p, l.id, l.qty);
            found.push(`${itemDef(l.id).name}×${l.qty}`);
          }
        }
      }
      if (found.length) lines.push(`你在尸体上翻找，拿到了：${found.join('、')}。`);
      this.log(p.id, lines, 'combat');
      this.feed(`${p.name} 在 ${this.locName(p.loc)} 清理了 ${enemies.length} 个威胁。`);

      // NPC 战斗结果
      if (c.npcId) {
        const npc = this.world.npcs.find(n => n.id === c.npcId);
        if (npc) {
          npc.alive = false;
          this.dropCorpse(p.loc, npc.name, npc.stock);
          this.feed(`${npc.name} 倒在了 ${this.locName(p.loc)}。`);
          if (npc.kind === 'orderly') {
            p.karma = (p.karma || 0) - 3;
            this.log(p.id, ['你杀了守序者。红布条上的颜色被血浸深了。你知道这件事会传出去。'], 'status');
          } else if (npc.kind === 'scavenger') {
            p.karma = (p.karma || 0) - 1;
          } else {
            p.karma = (p.karma || 0) + 1;
            this.log(p.id, ['你干掉了一个掠夺者。这片区域会因此安静一点。'], 'status');
          }
        }
      }
      p.combat = null;
      this.save(true);
      return;
    }
    if (p.hp <= 0) {
      this.killPlayer(p, '你倒在自己流出的血里，视野从边缘开始变黑。');
      return;
    }
    if (r.fled) {
      p.combat = null;
      this.log(p.id, ['你喘着气，退到掩体后面。四周重新安静下来。'], 'combat');
      this.pushView(p.id);
    }
  }

  dropCorpse(loc, name, stock) {
    if (!this.world.corpses[loc]) this.world.corpses[loc] = [];
    this.world.corpses[loc].push({ name, stock: (stock || []).map(s => ({ id: s.id, qty: s.qty })).slice(0, 4) });
  }

  /* ---------------- 死亡 ---------------- */
  killPlayer(p, text) {
    if (p.dead) return;
    p.dead = true;
    p.combat = null;
    p.hp = 0;
    p.deathCount = (p.deathCount || 0) + 1;
    p.flags.rest = false;
    this.log(p.id, [text, '眼前的一切慢慢退成灰色。', '你听见很远的地方有人在说话，但已经听不清了。'], 'death');
    this.send(p.id, { t: 'dead' });
    this.feed(`${p.name} 倒在了 ${this.locName(p.loc)}。`);
    // 队友精神打击
    if (p.party) {
      for (const m of this.partyMembers(p.party)) {
        if (m.id === p.id) continue;
        m.sanity = clamp(m.sanity - 12, 0, 100);
        this.log(m.id, [`你听见了 ${p.name} 倒下的声音。`, '你没能赶过去。'], 'status');
      }
    }
    // 掉落部分物资在地上
    const dropCount = Math.min(p.inv.length, Math.ceil(p.inv.length * 0.3));
    for (let i = 0; i < dropCount; i++) {
      const slot = p.inv[Math.floor(Math.random() * p.inv.length)];
      if (!slot || slot.qty <= 0) continue;
      if (!this.world.ground[p.loc]) this.world.ground[p.loc] = [];
      this.world.ground[p.loc].push({ id: slot.id, qty: slot.qty });
      slot.qty = 0;
    }
    p.inv = p.inv.filter(s => s.qty > 0);
    this.save(true);
    this.pushView(p.id);
  }

  doRevive(p) {
    if (!p.dead) return this.pushView(p.id);
    const deathLoc = p.loc;
    const hide = p.hideout.loc;
    if (!hide) {
      // 没有据点，只能在起点醒来
      p.loc = START_LOC;
    } else {
      p.loc = hide;
    }
    // 丢失大部分随身物资
    const keep = [];
    for (const slot of p.inv) {
      if (chance(0.25)) keep.push(slot);
    }
    p.inv = keep;
    const d = C.derived(p);
    p.dead = false;
    p.mutating = false;
    p.hp = Math.round(d.hpMax * 0.35);
    p.hunger = 28; p.thirst = 22; p.stamina = 35; p.pain = 30; p.sanity = 40;
    p.infection = Math.max(0, p.infection - 30);
    p.injuries = p.injuries.filter(i => i.type === 'fracture' && i.sev > 6).slice(0, 1);
    p.injuries.forEach(i => { i.bleed = false; });
    p.flags.rest = false;
    this.log(p.id, [
      '你在潮湿的地面上醒来。',
      hide ? `这里是你的据点——${this.locName(p.loc)}。有人把你拖了回来，或者是你自己爬回来的。` : '你在一片废墟里醒来，不知道这是哪里。',
      '身上的东西少了很大一部分。背包轻了，轻得让人心慌。',
      '伤口结了层薄薄的痂，血止住了。你还活着。',
    ], 'status');
    this.feed(`${p.name} 从死亡边缘爬了回来。`);
    this.save(true);
    this.pushView(p.id);
  }

  doDelete(p) {
    this.feed(`${p.name} 的角色被永远删除。这个人的故事到此为止。`);
    this.players.delete(p.id);
    const conn = this.conns.get(p.id);
    if (conn) conn.send({ t: 'deleted' });
    this.conns.delete(p.id);
    this.save(true);
  }

  /* ---------------- 传闻 ---------------- */
  newRumor() {
    const targets = ['junying', 'yiyuan', 'cangku', 'ditan', 'jingju', 'chaoshi', 'shoufeizhan'];
    const loc = pick(targets);
    const truth = chance(0.45);
    const templates = {
      junying: ['有人说军营的军械库还有没开封的箱子，锁是老式的，撬棍就能开。', '无线电里提过一句：营区油料库还有柴油，够一台发电机跑三天。'],
      yiyuan: ['医院药房最里层有一批没登记的抗生素，压在最底下的纸箱里。', '有人在门诊楼看到过穿白大褂的人影，往地下走，手里抱着冷藏箱。'],
      cangku: ['河堤仓库的 37 号集装箱，据说从来没被打开过。', '有人在仓库办公室捡到过一张货单，上面有一栏写着"特殊物资 · 勿动"。'],
      ditan: ['中继塔的机房还通着电，里面有一整柜子电池和零件。', '有人在塔下听到过电台的声音，说那里有备份的通讯设备。'],
      jingju: ['警察局地下车库有辆巡逻车，后备箱里可能还有整套装备。', '分局枪械柜的第二层，据说没人打开过。'],
      chaoshi: ['超市后仓的铁门后面还有一批货，没人搬完。', '有人看见生鲜冷柜里塞着东西，不是食物。'],
      shoufeizhan: ['收费站路政仓库里有撬棍和整套工具，还有一箱没开封的净水。', '堵在最前面的那辆货车，车厢里还有货。'],
    };
    const text = pick(templates[loc]);
    const rumor = {
      id: 'r' + uid(4), text, loc, locName: this.locName(loc), truth,
      expiresAt: this.world.clockMin + rint(180, 420),
    };
    this.world.rumors = [rumor];
    this.world.rumorAt = this.world.clockMin + rint(300, 600);
    this.feed(`〔传闻〕${text}`);
  }

  doChaseRumor(p) {
    const r = this.world.rumors[0];
    if (!r || r.loc !== p.loc) return this.send(p.id, { t: 'err', msg: '这里没有什么值得追查的传闻。' });
    if (this.world.clockMin > r.expiresAt) return this.log(p.id, ['这条线索已经过时了，地方早被人翻过。'], 'warn');
    if (r.chased && r.chased[p.id]) return this.log(p.id, ['这条线索你已经查过了。'], 'warn');
    r.chased = r.chased || {};
    r.chased[p.id] = true;
    this.log(p.id, ['你按着传闻里的说法，往那个方向摸过去。']);
    if (r.truth) {
      const bonus = { key: 'rumor', name: '传闻中的位置', loot: 'vault', cap: 2 };
      this.world.specialContainers = this.world.specialContainers || {};
      this.world.specialContainers[p.loc] = [bonus];
      this.world.containers[p.loc].rumor = { left: 2 };
      this.log(p.id, [
        '你找到了地方：门锁是新的，撬痕很少，里面的灰比外面薄。',
        '这里确实还没被人翻干净。',
        '〔出现新的可搜索地点：传闻中的位置〕',
      ], 'status');
      C.gainXp(p, 10);
    } else {
      this.log(p.id, [
        '你绕了两圈，只找到一间被翻得底朝天的空屋。地上的脚印很新，不止一个人。',
        '然后你听见身后有布料摩擦的声音。',
      ]);
      const enemies = CB.makeEnemies(locDef(p.loc).type);
      CB.startCombat(p, enemies, { sneak: false, lines: ['这是个陷阱。'] });
      this.log(p.id, ['【中伏】'], 'combat');
    }
    this.pushView(p.id);
  }

  /* ---------------- 聊天 / 组队 ---------------- */
  doChat(p, msg) {
    const text = String(msg.text || '').slice(0, 500);
    if (!text.trim()) return;
    if (msg.ch === 'party' && p.party) {
      for (const m of this.partyMembers(p.party)) {
        this.send(m.id, { t: 'chat', ch: 'party', from: p.name, text });
      }
    } else {
      this.broadcast({ t: 'chat', ch: 'room', from: p.name, text });
    }
  }

  doParty(p, msg) {
    const op = msg.op;
    if (op === 'invite') {
      const target = Array.from(this.players.values()).find(o => o.id === msg.target || o.name === msg.target);
      if (!target || target.id === p.id) return this.send(p.id, { t: 'err', msg: '没找到那个玩家。' });
      if (target.loc !== p.loc) return this.log(p.id, ['你们不在同一个地方，喊不应。'], 'warn');
      target.invites = target.invites || [];
      if (!target.invites.includes(p.id)) target.invites.push(p.id);
      this.log(p.id, [`你向 ${target.name} 打了个手势，示意结队。`]);
      this.send(target.id, { t: 'invite', from: p.name, fromId: p.id });
      this.log(target.id, [`${p.name} 向你伸出手："一起走？"`], 'status');
      return this.pushView(p.id);
    }
    if (op === 'accept') {
      const inviter = this.players.get(msg.from);
      if (!inviter) return this.send(p.id, { t: 'err', msg: '邀请已经失效。' });
      const partyId = inviter.party || inviter.id;
      if (!inviter.party) inviter.party = inviter.id;
      p.party = partyId;
      p.invites = [];
      this.log(p.id, [`你加入了 ${inviter.name} 的队伍。`], 'status');
      for (const m of this.partyMembers(partyId)) {
        this.log(m.id, [`${p.name} 加入了队伍。`], 'status');
      }
      this.feed(`${p.name} 与 ${inviter.name} 结成了小队。`);
      return this.pushView(p.id);
    }
    if (op === 'leave') {
      const partyId = p.party;
      if (!partyId) return this.pushView(p.id);
      p.party = null;
      for (const m of this.partyMembers(partyId)) {
        this.log(m.id, [`${p.name} 离开了队伍。`], 'status');
      }
      this.log(p.id, ['你脱离了队伍。'], 'status');
      return this.pushView(p.id);
    }
    if (op === 'kick') {
      if (p.party !== p.id) return this.send(p.id, { t: 'err', msg: '只有队长能踢人。' });
      const target = this.players.get(msg.target);
      if (!target || target.party !== p.id) return this.send(p.id, { t: 'err', msg: '队伍里没有这个人。' });
      target.party = null;
      this.log(target.id, ['你被移出了队伍。'], 'status');
      this.log(p.id, [`你把 ${target.name} 移出了队伍。`], 'status');
      return this.pushView(p.id);
    }
  }

  doPvp(p, msg) {
    const target = this.players.get(msg.target);
    if (!target || target.id === p.id || target.dead) return this.send(p.id, { t: 'err', msg: '找不到那个目标。' });
    if (target.loc !== p.loc) return this.send(p.id, { t: 'err', msg: '你们不在同一个地方。' });
    const op = msg.op;
    if (op === 'attack') {
      if (p.combat) return this.send(p.id, { t: 'err', msg: '你先处理眼前的敌人。' });
      const w = C.derived(p).weapon;
      const dmg = CB.weaponDamage(p, w);
      const res = C.takeDamage(target, dmg, { kind: 'human', injuryChance: 0.3 });
      this.log(p.id, [
        `你从侧面出手，${itemDef(w).name} 带着风声落下去。`,
        `${target.name} 闷哼一声，退了两步，${res.injury || '衣服被划开'}。`,
      ], 'combat');
      this.log(target.id, [
        `你被 ${p.name} 从背后打了一下。`,
        `你受到 ${res.reduced} 点伤害${res.injury ? `，${res.injury}` : ''}。`,
        '他手里握着武器，眼神不太对。',
      ], 'combat');
      this.feed(`${p.name} 在 ${this.locName(p.loc)} 袭击了 ${target.name}。`);
      if (target.hp <= 0) this.killPlayer(target, `你被 ${p.name} 打倒在地上，血从嘴里涌出来。`);
      // 反击
      if (target.hp > 0 && target.alive && chance(0.55)) {
        const tdmg = CB.weaponDamage(target, C.derived(target).weapon);
        const r2 = C.takeDamage(p, Math.round(tdmg * 0.7), { kind: 'human', injuryChance: 0.2 });
        this.log(target.id, [`你反手还了一下，${p.name} 受到 ${r2.reduced} 点伤害。`], 'combat');
        this.log(p.id, [`${target.name} 反手还击，你受到 ${r2.reduced} 点伤害。`], 'combat');
        if (p.hp <= 0) this.killPlayer(p, `你被 ${target.name} 的反击打倒。`);
      }
      this.pushView(p.id);
      this.pushView(target.id);
      return;
    }
    if (op === 'rob') {
      const pWin = chance(clamp(0.35 + p.attrs.agi * 0.03 - target.attrs.per * 0.02, 0.1, 0.85));
      if (!pWin) {
        this.log(p.id, [`你伸手去掏 ${target.name} 的背包，被他一把打开。`, '他的手已经按在武器上了。'], 'combat');
        this.log(target.id, [`${p.name} 伸手掏你的包，被你挡开了。`], 'combat');
        return this.pushView(p.id);
      }
      const slots = target.inv.filter(s => s.qty > 0);
      if (!slots.length) {
        this.log(p.id, [`${target.name} 的包里几乎什么都没有。`]);
        return this.pushView(p.id);
      }
      const slot = pick(slots);
      const q = Math.min(slot.qty, rint(1, 2));
      C.removeItem(target, slot.id, q);
      C.addItem(p, slot.id, q);
      this.log(p.id, [`你从 ${target.name} 身上摸走了 ${itemDef(slot.id).name} ×${q}。`], 'combat');
      this.log(target.id, [`${p.name} 从你身上抢走了 ${itemDef(slot.id).name} ×${q}。`], 'combat');
      this.feed(`${p.name} 抢了 ${target.name} 的物资。`);
      this.pushView(p.id);
      this.pushView(target.id);
      return;
    }
    if (op === 'bandage') {
      if (!C.countItem(p, 'bandage')) return this.send(p.id, { t: 'err', msg: '你没有绷带。' });
      C.consumeItem(p, 'bandage', 1);
      C.heal(target, 18);
      for (const i of target.injuries) if (i.bleed) i.bleed = false;
      this.log(p.id, [`你让 ${target.name} 坐下，用绷带把伤口一圈圈缠紧。`, '血慢慢止住了。'], 'narr');
      this.log(target.id, [`${p.name} 替你包扎了伤口。`, '疼痛退了一些，你感觉暖和了点。'], 'narr');
      target.sanity = clamp(target.sanity + 4, 0, 100);
      this.pushView(p.id);
      this.pushView(target.id);
      return;
    }
  }

  doGive(p, msg) {
    const target = this.players.get(msg.target);
    if (!target || target.loc !== p.loc) return this.send(p.id, { t: 'err', msg: '对方不在这里。' });
    const q = Math.max(1, msg.qty || 1);
    if (!C.countItem(p, msg.item)) return this.send(p.id, { t: 'err', msg: '你身上没有这件东西。' });
    C.removeItem(p, msg.item, q);
    C.addItem(target, msg.item, q);
    this.log(p.id, [`你把 ${itemDef(msg.item).name} ×${q} 递给了 ${target.name}。`]);
    this.log(target.id, [`${p.name} 递给你 ${itemDef(msg.item).name} ×${q}。`], 'status');
    this.pushView(p.id);
    this.pushView(target.id);
  }

  /* ---------------- 据点夜袭 ---------------- */
  checkRaid(hour) {
    const w = this.world;
    if (hour !== 22 && hour !== 1 && hour !== 3) return;
    if (w.lastRaidHour === hour && w.lastRaidDay === this.day) return;
    w.lastRaidHour = hour;
    w.lastRaidDay = this.day;
    for (const p of this.players.values()) {
      if (p.dead || !p.hideout.loc) continue;
      if (!chance(0.45)) continue;
      const hb = p.hideout.buildings;
      let strength = rint(2, 4);
      if (hb.wall) strength -= 1;
      if (hb.trap) strength -= 1;
      if (hb.alarm) this.log(p.id, ['据点外的警戒线被碰响了——有人，或者有什么东西，正朝这里过来。'], 'status');
      strength = Math.max(1, strength);
      if (p.loc !== p.hideout.loc) {
        // 不在家：被洗劫
        const stolen = [];
        for (const s of p.hideout.storage) {
          if (chance(0.55)) {
            stolen.push(`${itemDef(s.id).name}×${s.qty}`);
            s.qty = 0;
          }
        }
        p.hideout.storage = p.hideout.storage.filter(s => s.qty > 0);
        this.log(p.id, [
          '你在外面过夜。',
          `夜里，${this.locName(p.hideout.loc)} 传来了动静。等你赶回去，储物处被翻开，地上留着陌生的脚印。`,
          stolen.length ? `丢失：${stolen.join('、')}。` : '东西没丢多少，但门被砸开了。',
          hb.wall ? '围墙拖住了它们一阵，不然会丢得更多。' : '如果有一圈围墙，损失会小一些。',
        ], 'status');
        this.feed(`${p.name} 的据点于夜间被洗劫。`);
      } else {
        // 在家：防守战
        const enemies = [];
        for (let i = 0; i < strength; i++) {
          const type = chance(0.7) ? 'walker' : chance(0.6) ? 'runner' : 'raider';
          const def = ENEMIES[type];
          enemies.push({ uid: 'e' + uid(4), type, name: def.name, hp: def.hp, maxHp: def.hp, desc: def.desc });
        }
        p.combat = {
          enemies, round: 1, sneak: false, aimed: 0, human: enemies.every(e => ENEMIES[e.type].kind === 'human'),
          startAt: Date.now(), looted: false, raid: true,
        };
        this.log(p.id, [
          '夜里，据点外的声音近了。',
          hb.alarm ? '警戒装置先响了起来，你从睡梦中惊醒。' : '你是被门板被撞的声音惊醒的。',
          hb.trap ? '外面的陷阱触发了一声闷响，有什么东西被钉住了。' : '',
          `你抓起武器，站到门后。【守据点】`,
        ].filter(Boolean), 'combat');
        this.feed(`${p.name} 的据点在夜间遭到袭击。`);
        this.pushView(p.id);
      }
    }
  }
}

module.exports = { Room, WEATHER };
