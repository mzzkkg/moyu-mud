'use strict';
const { ENEMIES, ENCOUNTERS } = require('../data/enemies');
const { LOOT } = require('../data/loot');
const { itemDef } = require('../data/items');
const { rint, chance, pick, weighted, clamp } = require('./util');
const C = require('./character');

/** 掷一次战利品 */
function rollLoot(tableId, danger = 1, count = 1) {
  const table = LOOT[tableId] || LOOT.junk;
  const out = [];
  for (let i = 0; i < count; i++) {
    const allowed = table.filter(e => (e.rar || 1) <= danger + 1 || chance(0.12));
    if (!allowed.length) continue;
    const entry = weighted(allowed);
    const qty = rint(entry.qty[0], entry.qty[1]);
    out.push({ id: entry.id, qty });
  }
  return out;
}

function makeEnemies(type) {
  const table = ENCOUNTERS[type] || ENCOUNTERS.urban;
  const entry = weighted(table);
  const n = rint(entry.n[0], entry.n[1]);
  const enemies = [];
  for (let i = 0; i < n; i++) {
    const def = ENEMIES[entry.id];
    enemies.push({
      uid: 'e' + Math.random().toString(36).slice(2, 7),
      type: entry.id,
      name: def.name,
      hp: def.hp,
      maxHp: def.hp,
      desc: def.desc,
    });
  }
  return enemies;
}

/** 遭遇概率：危险等级 + 噪音 + 夜晚 + 天气 */
function encounterChance(loc, world, ch, noise = 0) {
  if (loc.safe) return 0;
  const d = C.derived(ch);
  let base = loc.danger * 0.05 + 0.02;
  base += d.noise * 0.01 + noise * 0.02;
  if (world.isNight) base += 0.06;
  if (world.weather === 'fog') base -= 0.02;
  if (world.weather === 'sandstorm') base -= 0.03;
  if (world.weather === 'rain') base -= 0.01; // 雨声掩盖脚步
  base *= (ch.flags.flashlight && world.isNight) ? 1.3 : 1;
  return clamp(base, 0, 0.55);
}

function startCombat(ch, enemies, opts = {}) {
  ch.combat = {
    enemies,
    round: 1,
    sneak: !!opts.sneak,
    aimed: 0,
    human: enemies.every(e => ENEMIES[e.type].kind === 'human'),
    startAt: Date.now(),
    looted: false,
    startLines: opts.lines || [],
  };
  return ch.combat;
}

function weaponDamage(ch, weaponId) {
  const def = itemDef(weaponId);
  const base = def.dmg || [3, 7];
  const d = C.derived(ch);
  const skillKey = def.skill || 'melee';
  const skill = ch.skills[skillKey] || 0;
  const strBonus = skillKey === 'melee' ? ch.attrs.str * 0.45 : ch.attrs.agi * 0.15;
  let dmg = rint(base[0], base[1]) + strBonus + skill * 1.1;
  dmg *= (1 - clamp(ch.pain / 260, 0, 0.35));
  return Math.max(1, Math.round(dmg));
}

function hitChance(ch, enemy, weaponId, aimed = 0) {
  const def = itemDef(weaponId);
  const d = C.derived(ch);
  const skillKey = def.skill || 'melee';
  let acc = 0.62 + ch.attrs.agi * 0.018 + (ch.skills[skillKey] || 0) * 0.03 + (def.acc || 0);
  acc -= clamp(ch.pain / 220, 0, 0.25);
  acc += aimed * 0.18;
  const e = ENEMIES[enemy.type];
  acc -= (e.speed - 1) * 0.06;
  acc -= d.overload * 0.1;
  return clamp(acc, 0.15, 0.95);
}

function enemyAttack(enemy, ch, world, lines) {
  const def = ENEMIES[enemy.type];
  if (chance(def.acc - ch.attrs.agi * 0.012)) {
    const raw = rint(def.dmg[0], def.dmg[1]);
    const res = C.takeDamage(ch, raw, {
      kind: def.kind,
      injuryChance: def.kind === 'zombie' ? 0.32 : 0.18,
    });
    lines.push(pick(def.hit));
    lines.push(`你受到 ${res.reduced} 点伤害${res.injury ? `，${res.injury}了` : ''}。`);
    if (def.kind === 'zombie') {
      const mask = C.getMask(ch);
      const protect = mask ? itemDef(mask).protect : 0;
      let inf = rint(2, 5) * (1 - protect);
      if (chance(0.4)) inf += 3;
      ch.infection = clamp(ch.infection + Math.round(inf), 0, 100);
      lines.push(`伤口接触到它的体液，感染值上升。（感染 ${Math.round(ch.infection)}）`);
    }
  } else {
    lines.push(pick([
      `${def.name} 扑了个空，你侧身躲开，能闻到它身上腐烂的气味。`,
      `它伸出的手擦着你的耳侧过去，指甲刮下几根头发。`,
      `你后退半步，${def.name} 的重心偏了，踉跄着撞在墙上。`,
      `你抬臂格了一下，它的牙咬在袖子上，没咬到肉。`,
    ]));
  }
}

function combatAction(room, ch, act, targetIdx = 0) {
  const c = ch.combat;
  if (!c) return { lines: ['你没有在战斗。'], ended: true };
  const lines = [];
  const d = C.derived(ch);
  const weaponId = d.weapon;
  const wdef = itemDef(weaponId);
  let ended = false;
  let victory = false;

  const target = c.enemies[targetIdx] && c.enemies[targetIdx].hp > 0 ? c.enemies[targetIdx] : c.enemies.find(e => e.hp > 0);

  const alliesHere = room.playersInLoc(ch.loc).filter(p => p !== ch && p.party === ch.party && ch.party && p.alive);

  if (act === 'attack' || act === 'stealth' || act === 'aim') {
    if (!target) { ended = true; }
    else if (act === 'aim' && wdef.skill === 'firearms') {
      c.aimed = Math.min(3, c.aimed + 1);
      ch.stamina = Math.max(0, ch.stamina - 2);
      if (chance(0.3)) C.trainSkill(ch, 'firearms', 1);
      lines.push('你稳住呼吸，把准星压在它胸口的位置，慢慢收紧手指。');
    } else if (act === 'aim') {
      c.aimed = Math.min(2, c.aimed + 1);
      lines.push('你压住呼吸，握紧武器，等一个更好的角度。');
    } else {
      // 弹药检查
      let noAmmo = false;
      if (wdef.ammo) {
        if (C.countItem(ch, wdef.ammo) <= 0) {
          noAmmo = true;
          lines.push('你扣下扳机，只听见一声空响。弹匣是空的。');
          lines.push('你只能用空手应对。');
        } else {
          C.removeItem(ch, wdef.ammo, 1);
        }
      }
      const stealth = act === 'stealth';
      let hit = hitChance(ch, target, noAmmo ? 'fists' : weaponId, c.aimed);
      if (stealth) hit += 0.08;
      const boss = ENEMIES[target.type];
      if (stealth && boss.traits && boss.traits.includes('hearing') && chance(0.45)) {
        hit -= 0.15;
        lines.push(`${boss.name} 的耳朵动了一下——它听见了你的呼吸。`);
        c.sneak = false;
      }
      if (stealth && chance(0.15)) lines.push('你的脚步踩到一枚碎玻璃，清脆的一声在空气里炸开。');

      if (chance(hit)) {
        let dmg = weaponDamage(ch, noAmmo ? 'fists' : weaponId);
        if (stealth) dmg = Math.round(dmg * 2.1);
        if (c.aimed) dmg = Math.round(dmg * (1 + c.aimed * 0.12));
        dmg = Math.max(1, dmg - Math.max(0, (boss.armor || 0) - (wdef.armorPierce || 0)));
        target.hp -= dmg;
        const crit = chance(0.14);
        if (crit) { target.hp -= Math.round(dmg * 0.3); }
        lines.push(stealth
          ? `你从阴影里贴上去，${wdef.name} 从它后颈斜插进去。它连一声都没发出就软了下去。（造成 ${dmg} 点伤害）`
          : pick([
            `你用 ${wdef.name} 砸在它身上，沉闷的一击。（造成 ${dmg} 点伤害）`,
            `${wdef.name} 带着风声落下，正中它的肩颈。（造成 ${dmg} 点伤害）`,
            `你抢上一步，${wdef.name} 狠狠压进它的胸口。（造成 ${dmg} 点伤害）`,
          ]));
        if (crit) lines.push('你感觉到骨头碎裂的震动，这一下正中要害。');
        const wdefBleed = wdef.bleed;
        if (wdefBleed && chance(wdefBleed)) {
          lines.push(`${boss.name} 身上裂开一道口子，暗色的液体涌出来。`);
          target.hp -= 4;
        }
        if (noAmmo) lines.push('拳头打在它的皮肉上，像打在湿泥里。');
        C.trainSkill(ch, wdef.skill || 'melee', 1);
      } else {
        lines.push(`你挥空了。${boss.name} 在最后一刻偏开了身体，你听见自己的心跳。`);
      }
      if (stealth) c.sneak = false;
      c.aimed = 0;
      if (boss.traits && boss.traits.includes('ranged') && chance(0.5)) {
        lines.push('枪声在空旷处炸开，回音一层层荡出去——附近的东西都会听见。');
        room.addNoise(ch.loc, 3);
      } else if (wdef.noise >= 8) {
        room.addNoise(ch.loc, 2);
      }
      C.trainSkill(ch, 'melee', 0.5);
    }
  } else if (act === 'flee') {
    const fastest = Math.max(...c.enemies.filter(e => e.hp > 0).map(e => ENEMIES[e.type].speed));
    const p = clamp(0.45 + ch.attrs.agi * 0.025 - fastest * 0.07 - d.overload * 0.15, 0.1, 0.9);
    if (chance(p)) {
      lines.push('你转身就跑，脚步踏在碎石上，身后传来它拖行的声音，然后越来越远。');
      ch.combat = null;
      return { lines, ended: true, victory: false, fled: true };
    }
    lines.push('你转身的瞬间被拽住了衣角，重心一失，整个人摔在地上。');
    ended = false;
  } else if (act === 'negotiate') {
    if (!c.human) {
      lines.push('丧尸听不懂你的话，它只想要你身上的肉。');
    } else {
      const p = clamp(0.35 + ch.attrs.per * 0.03 + ch.sanity / 400, 0.15, 0.9);
      if (chance(p)) {
        lines.push('你举起空着的那只手，压低声音说：我们没必要都死在这儿。');
        lines.push('对方犹豫了，枪口慢慢垂下，退开两步，然后转身走了。');
        ch.combat = null;
        return { lines, ended: true, victory: false, fled: true };
      }
      lines.push('对方冷笑了一声："把包扔过来。"——你没能说服他。');
    }
  } else if (act === 'disarm') {
    if (!c.human) {
      lines.push('你试图打掉它的武器，但那只手根本没有握住任何东西。');
    } else {
      const p = clamp(0.3 + ch.attrs.agi * 0.03 + (ch.skills.melee || 0) * 0.02, 0.1, 0.85);
      if (chance(p)) {
        lines.push('你抓住他手腕的瞬间一拧，木棍脱手飞出去，在地上转了两圈。');
        const e = ENEMIES[target.type];
        target.dmgOverride = Math.max(3, e.dmg[0] - 4);
        target.disarmed = true;
      } else {
        lines.push('你抓了个空，对方反手一肘撞在你胸口。');
      }
    }
  } else if (act === 'throw') {
    const mol = C.findSlot(ch, 'molotov');
    if (!mol) lines.push('你没有燃烧瓶。');
    else {
      C.consumeItem(ch, 'molotov', 1);
      const dmg = rint(18, 30);
      if (target) {
        target.hp -= dmg;
        lines.push(`瓶子在它身上炸开，火苗顺着破布窜起来。（造成 ${dmg} 点伤害）`);
      }
      for (const e of c.enemies) {
        if (e.hp > 0 && e !== target && chance(0.35)) {
          e.hp -= 8;
          lines.push(`${e.name} 也被火舌扫到，发出刺耳的嘶叫。`);
        }
      }
      room.addNoise(ch.loc, 2);
    }
  } else if (act === 'use') {
    // 由上层处理具体物品
    lines.push('你腾出一只手处理伤口。');
  } else if (act === 'taunt') {
    lines.push('你大吼一声，声音在空处散开。');
  }

  // 队友支援
  if (alliesHere.length && !ended) {
    for (const ally of alliesHere) {
      const ad = C.derived(ally);
      if (chance(0.55)) {
        const t = c.enemies.find(e => e.hp > 0);
        if (t) {
          const dmg = Math.max(1, rint(4, 9) + ally.attrs.str);
          t.hp -= dmg;
          lines.push(`${ally.name} 在旁边补了一下，${t.name} 被击中（${dmg} 点伤害）。`);
        }
      }
    }
  }

  // 敌人回合
  if (!c.enemies.some(e => e.hp > 0)) {
    victory = true;
    ended = true;
  } else if (ch.hp > 0) {
    c.round += 1;
    const alive = c.enemies.filter(e => e.hp > 0);
    for (const e of alive) {
      const def = ENEMIES[e.type];
      if (def.traits && def.traits.includes('spawner') && chance(0.35) && c.enemies.length < 8) {
        const spawn = {
          uid: 'e' + Math.random().toString(36).slice(2, 7),
          type: 'walker', name: '普通丧尸', hp: 44, maxHp: 44,
          desc: '从母体裂开的囊袋里滑出来，身上还裹着一层黏液。',
        };
        c.enemies.push(spawn);
        lines.push('母体的囊袋裂开，一只新的丧尸从里面滑出来，落在地上，立刻抬起头。');
      }
      enemyAttack(e, ch, null, lines);
      if (ch.hp <= 0) break;
    }
    // 队友也会挨打
    for (const ally of alliesHere) {
      if (chance(0.4) && ally.hp > 0) {
        const e = pick(alive);
        const def = ENEMIES[e.type];
        const res = C.takeDamage(ally, rint(def.dmg[0], def.dmg[1]) - 2, { kind: def.kind, injuryChance: 0.2 });
        lines.push(`${ally.name} 也被 ${def.name} 缠住了，受了 ${res.reduced} 点伤。`);
        room.feed(`${ally.name} 在 ${room.locName(ch.loc)} 与你并肩作战，受了伤。`);
      }
    }
    if (ch.hp <= 0) {
      ended = true;
    }
  }

  if (c) {
    if (c.enemies.every(e => e.hp <= 0)) { victory = true; ended = true; }
    if (ch.hp <= 0) ended = true;
  }

  if (ended && victory && c) {
    ch.stats.kills += c.enemies.length;
  }

  return { lines, ended, victory, enemies: c ? c.enemies : [] };
}

function xpForEnemies(enemies) {
  return enemies.reduce((s, e) => s + (ENEMIES[e.type]?.xp || 10), 0);
}

module.exports = { rollLoot, makeEnemies, encounterChance, startCombat, combatAction, xpForEnemies, weaponDamage, hitChance };
