@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [错误] 没有找到 Node.js
  echo 请先安装：https://nodejs.org/zh-cn   选 LTS 版
  echo.
  pause
  exit /b
)
echo 正在启动末日余烬...
echo 启动后不要关闭这个窗口，按 Ctrl+C 停止
node server.js
pause
