'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { attach } = require('./lib/ws');
const { Room } = require('./game/room');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'worlds');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

const rooms = new Map(); // code -> Room
let lastActivity = 0;

function newCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  do {
    code = '';
    for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)];
  } while (rooms.has(code));
  return code;
}

function getRoom(code) {
  if (rooms.has(code)) return rooms.get(code);
  const room = new Room(code, DATA_DIR);
  rooms.set(code, room);
  return room;
}

function serveStatic(req, res) {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  const safe = path.normalize(urlPath).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(PUBLIC_DIR, safe);
  if (!file.startsWith(PUBLIC_DIR)) {
    res.writeHead(403).end('forbidden');
    return;
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('404 找不到页面');
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (url === '/api/rooms') {
    const list = [];
    for (const [code, room] of rooms) {
      list.push({ code, online: room.conns.size, world: room.timeStr ? room.timeStr() : '', players: room.players.size });
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, rooms: list.slice(0, 20), port: PORT }));
    return;
  }
  if (url === '/api/create') {
    const code = newCode();
    getRoom(code);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, code }));
    return;
  }
  if (url === '/api/check') {
    const q = new URL('http://x' + req.url).searchParams.get('code') || '';
    const upper = q.toUpperCase();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, exists: rooms.has(upper) || fs.existsSync(path.join(DATA_DIR, upper + '.json')) }));
    return;
  }
  serveStatic(req, res);
});

attach(server, (conn, req) => {
  conn.isAlive = true;
  let room = null;
  lastActivity = Date.now();

  const sendErr = (msg) => conn.send({ t: 'err', msg });

  conn.on('message', (raw) => {
    lastActivity = Date.now();
    let msg;
    try { msg = JSON.parse(raw); } catch (e) { return sendErr('消息格式错误'); }
    if (!msg || typeof msg !== 'object') return;

    if (msg.t === 'join') {
      const name = String(msg.name || '').trim().slice(0, 12);
      if (!name) return sendErr('给自己起个名字吧（最多 12 个字）。');
      let code = String(msg.room || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
      if (!code) {
        if (msg.create) code = newCode();
        else return sendErr('请输入房间码，或者直接创建房间。');
      } else if (!rooms.has(code) && !fs.existsSync(path.join(DATA_DIR, code + '.json'))) {
        if (!msg.create) return sendErr('房间不存在。检查房间码，或者点「创建新房间」。');
      }
      room = getRoom(code);
      const player = room.join(conn, name, msg.token);
      conn.send({ t: 'joined', code, token: player.id, name: player.name });
      return;
    }

    if (msg.t === 'act') {
      if (!room) return sendErr('还没进入房间。');
      if (conn.playerId) {
        const p = room.players.get(conn.playerId);
        if (p) room.handle(p, msg);
      }
      return;
    }

    if (msg.t === 'ping') {
      conn.send({ t: 'pong' });
    }
  });

  conn.on('close', () => {
    if (room && conn.playerId) room.leave(conn.playerId);
  });
});

// 全局心跳：每 1 秒推进所有房间
setInterval(() => {
  for (const room of rooms.values()) {
    try { room.tick(); } catch (e) { console.error('tick error', room.code, e); }
  }
}, 1000);

// 每 30 秒保存一次
setInterval(() => {
  for (const room of rooms.values()) {
    try { room.save(true); } catch (e) { /* ignore */ }
  }
}, 30000);

// 空闲房间卸载（30 分钟无人则从内存移除，数据仍在磁盘）
setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms) {
    if (room.conns.size === 0 && now - room.lastSave > 30 * 60 * 1000) {
      rooms.delete(code);
      console.log('卸载空闲房间', code);
    }
  }
}, 5 * 60 * 1000);

function localIPs() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const list of Object.values(ifs)) {
    for (const i of list || []) {
      if (i.family === 'IPv4' && !i.internal) out.push(i.address);
    }
  }
  return out;
}

server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  末日生存 MUD 已启动');
  console.log('  ─────────────────────────');
  console.log('  本机访问:  http://localhost:' + PORT);
  for (const ip of localIPs()) {
    console.log('  局域网:    http://' + ip + ':' + PORT + '   （手机连同一个 WiFi 可打开）');
  }
  console.log('  公网分享需要部署或内网穿透，见 README。');
  console.log('');
});
