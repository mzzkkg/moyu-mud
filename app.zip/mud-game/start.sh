#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "[错误] 没有找到 Node.js，请先安装 https://nodejs.org/zh-cn"
  exit 1
fi
echo "正在启动末日余烬... 按 Ctrl+C 停止"
node server.js
