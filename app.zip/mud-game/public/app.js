'use strict';
(function () {
  const $ = (s) => document.querySelector(s);
  const el = (tag, cls, html) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let ws = null;
  let view = null;
  let currentRoom = localStorage.getItem('mud_room') || '';
  let token = localStorage.getItem('mud_token') || '';
  let myName = localStorage.getItem('mud_name') || '';
  let selectedTarget = 0;
  let sheetTab = null;
  let invite = null;
  let connecting = false;
  let retried = 0;
  let lastSheetScroll = 0;
  let unread = 0;

  /* ---------------- 连接 ---------------- */
  function wsUrl() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    return proto + '://' + location.host;
  }

  function connect(room, name, create) {
    if (connecting) return;
    connecting = true;
    try { if (ws) ws.close(); } catch (e) { }
    ws = new WebSocket(wsUrl());
    ws.onopen = () => {
      connecting = false;
      retried = 0;
      ws.send(JSON.stringify({ t: 'join', room, name, token, create: !!create }));
    };
    ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      handle(msg);
    };
    ws.onclose = () => {
      connecting = false;
      if (!view) return;
      if (retried < 4) {
        retried++;
        toast('连接断开，正在重连…');
        setTimeout(() => connect(currentRoom, myName, false), 2200);
      } else {
        toast('连接断开，刷新页面重试');
      }
    };
    ws.onerror = () => { };
  }

  function send(obj) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
  }
  function act(a, extra) {
    send(Object.assign({ t: 'act', a }, extra || {}));
  }

  /* ---------------- 消息处理 ---------------- */
  function handle(msg) {
    switch (msg.t) {
      case 'joined':
        currentRoom = msg.code;
        token = msg.token;
        myName = msg.name;
        localStorage.setItem('mud_room', currentRoom);
        localStorage.setItem('mud_token', token);
        localStorage.setItem('mud_name', myName);
        $('#login').classList.add('hidden');
        $('#game').classList.remove('hidden');
        $('#deathScreen').classList.add('hidden');
        $('#roomCode').textContent = '房间 ' + msg.code;
        logLines([`你进入了房间 ${msg.code}。`], 'sys');
        break;
      case 'view':
        if (msg.combat && (!view || !view.combat)) {
          closeSheet();
          setActiveTab('act');
        }
        view = msg;
        renderAll();
        break;
      case 'log':
        logLines(msg.lines, msg.kind);
        break;
      case 'chat': {
        const tag = msg.ch === 'party' ? '[队伍]' : '[房间]';
        logLines([`${tag} ${msg.from}：${msg.text}`], 'chat');
        break;
      }
      case 'alert':
        toast(msg.text);
        break;
      case 'err':
        toast(msg.msg, true);
        break;
      case 'dead':
        closeSheet();
        $('#deathScreen').classList.remove('hidden');
        break;
      case 'deleted':
        localStorage.removeItem('mud_token');
        location.reload();
        break;
      case 'invite':
        invite = { from: msg.from, fromId: msg.fromId };
        toast(`${msg.from} 邀请你组队，去「队伍」里接受`);
        if (sheetTab === 'team') renderSheet();
        break;
      case 'weather':
        toast('天气变化：' + msg.text);
        break;
      case 'pong': break;
      default: break;
    }
  }

  /* ---------------- 日志 ---------------- */
  function logLines(lines, kind) {
    const panel = $('#logPanel');
    const atBottom = panel.scrollHeight - panel.scrollTop - panel.clientHeight < 80;
    for (const raw of lines || []) {
      const text = String(raw || '');
      if (!text) continue;
      let cls = 'line narr';
      if (kind === 'status') cls = 'line status';
      else if (kind === 'combat') cls = 'line combat';
      else if (kind === 'warn') cls = 'line warn';
      else if (kind === 'halluc') cls = 'line halluc';
      else if (kind === 'death') cls = 'line death';
      else if (kind === 'sys') cls = 'line sys';
      else if (kind === 'chat') cls = 'line chat';
      if (/^【.*】$/.test(text) && text.length < 30) cls = 'line head';
      const e = el('div', cls);
      e.textContent = text;
      panel.appendChild(e);
    }
    while (panel.children.length > 260) panel.removeChild(panel.firstChild);
    if (atBottom) panel.scrollTop = panel.scrollHeight;
    unread++;
  }

  function toast(text, bad) {
    const t = $('#toast');
    t.textContent = text;
    t.style.color = bad ? '#d0685e' : '#c9a227';
    t.style.borderColor = bad ? '#4a2320' : '#6d5a1a';
    t.classList.remove('hidden');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.add('hidden'), 2600);
  }

  /* ---------------- 渲染 ---------------- */
  function bar(cls, value, max, label, right) {
    const pct = Math.max(0, Math.min(100, (value / (max || 100)) * 100));
    return `<div class="vital">
      <div class="vital-top"><span>${label}</span><b>${right != null ? right : Math.round(value)}</b></div>
      <div class="bar ${cls}"><i style="width:${pct}%"></i></div>
    </div>`;
  }

  function renderAll() {
    if (!view) return;
    renderTop();
    renderStatus();
    renderCombat();
    renderActions();
    if (sheetTab) renderSheet();
  }

  function renderTop() {
    const w = view.world;
    $('#worldClock').textContent = w.time;
    const wt = $('#weatherTag');
    wt.textContent = w.weatherName + (w.night ? ' · 夜' : '');
    wt.className = 'tag ' + (w.night ? 'bad' : w.weather === 'rain' || w.weather === 'sandstorm' ? 'warn' : '');
    $('#onlineTag').textContent = w.online + ' 在线';
  }

  function renderStatus() {
    const me = view.me;
    const dmg = me.injuries.map(i => `<span class="chip bad ${i.bleed ? 'bleed' : ''}">${esc(i.name)}${i.sev ? '·' + i.sev : ''}${i.bleed ? ' 出血' : ''}</span>`).join('');
    const loadRatio = me.load / me.cap;
    const status = `
      <div class="vitals">
        ${bar('hp', me.hp, me.hpMax, '生命', `${me.hp}/${me.hpMax}`)}
        ${bar('hunger', me.hunger, 100, '饥饿', Math.round(me.hunger))}
        ${bar('thirst', me.thirst, 100, '口渴', Math.round(me.thirst))}
        ${bar('stamina', me.stamina, me.staminaMax, '体力', `${Math.round(me.stamina)}/${me.staminaMax}`)}
        ${bar('infection', me.infection, 100, '感染', Math.round(me.infection))}
        ${bar('sanity', me.sanity, 100, '精神', Math.round(me.sanity))}
        ${bar('pain', me.pain, 100, '疼痛', Math.round(me.pain))}
        <div class="vital">
          <div class="vital-top"><span>负重</span><b>${me.load}/${me.cap}kg</b></div>
          <div class="bar ${loadRatio > 1 ? 'pain' : 'stamina'}"><i style="width:${Math.min(100, loadRatio * 100)}%"></i></div>
        </div>
      </div>
      <div class="status-extra">
        <span class="chip">Lv.${me.level} · ${me.xp}/${me.xpNeed}</span>
        <span class="chip">力${me.attrs.str} 敏${me.attrs.agi} 体${me.attrs.con} 感${me.attrs.per}</span>
        ${me.points > 0 ? `<span class="chip good chip-btn" data-open="attr">可分配 ${me.points} 点 →</span>` : ''}
        <span class="chip ${view.loc.danger >= 4 ? 'bad' : view.loc.danger >= 3 ? 'warn' : ''}">危险 ${view.loc.danger}</span>
        <span class="chip">武器 ${esc(me.weapon)}</span>
        <span class="chip">护甲 ${me.armor}</span>
        ${me.resting ? '<span class="chip good">休息中</span>' : ''}
        ${me.flashlight ? '<span class="chip">手电开</span>' : ''}
        ${dmg}
        ${loadRatio > 1 ? '<span class="chip warn">超重·行动迟缓</span>' : ''}
        ${me.infection >= 40 ? '<span class="chip bad">感染加重</span>' : ''}
        ${me.sanity < 30 ? '<span class="chip bad">精神濒临崩溃</span>' : ''}
      </div>`;
    $('#statusPanel').innerHTML = status;
    $('#statusPanel').querySelectorAll('[data-open="attr"]').forEach(b => b.onclick = () => { sheetTab = 'attr'; renderSheet(); });
  }

  function renderCombat() {
    const panel = $('#combatPanel');
    const c = view.combat;
    if (!c) { panel.classList.add('hidden'); panel.innerHTML = ''; return; }
    panel.classList.remove('hidden');
    const enemies = c.enemies.map((e, i) => `
      <div class="enemy-row ${i === selectedTarget ? 'sel' : ''} ${e.dead ? 'dead' : ''}" data-idx="${i}">
        <div class="enemy-head"><span>${esc(e.name)}${e.disarmed ? ' · 已缴械' : ''}</span><span class="enemy-hp">${e.hp}/${e.maxHp}</span></div>
        <div class="enemy-desc">${esc(e.desc || '')}</div>
        <div class="enemy-bar"><i style="width:${Math.max(0, (e.hp / e.maxHp) * 100)}%"></i></div>
      </div>`).join('');
    panel.innerHTML = `<div class="combat-hint">第 ${c.round} 回合 · ${c.sneak ? '你尚未暴露' : '已暴露'} · 点敌人可切换目标</div>${enemies}`;
    panel.querySelectorAll('.enemy-row').forEach(row => {
      row.onclick = () => { selectedTarget = Number(row.dataset.idx); renderAll(); };
    });
  }

  function actionBtn(label, cls, fn, extra) {
    const b = el('button', 'act ' + (cls || ''), esc(label));
    b.onclick = fn;
    return b;
  }

  function renderActions() {
    const bar = $('#actionBar');
    const prev = bar.scrollLeft;
    bar.innerHTML = '';
    const me = view.me;
    const loc = view.loc;
    const c = view.combat;

    if (c) {
      bar.appendChild(actionBtn('攻击', 'primary', () => act('combat', { act: 'attack', target: selectedTarget })));
      if (c.canStealth) bar.appendChild(actionBtn('潜行突袭', 'danger', () => act('combat', { act: 'stealth', target: selectedTarget })));
      bar.appendChild(actionBtn(c.aimed ? `瞄准(${c.aimed})` : '瞄准', 'dim', () => act('combat', { act: 'aim', target: selectedTarget })));
      if (c.human) {
        bar.appendChild(actionBtn('谈判', 'dim', () => act('combat', { act: 'negotiate', target: selectedTarget })));
        bar.appendChild(actionBtn('缴械', 'dim', () => act('combat', { act: 'disarm', target: selectedTarget })));
      }
      bar.appendChild(actionBtn('用绷带', '', () => act('combat', { act: 'use', item: 'bandage', target: selectedTarget })));
      if (c.hasMolotov) bar.appendChild(actionBtn('扔燃烧瓶', 'danger', () => act('combat', { act: 'throw', target: selectedTarget })));
      bar.appendChild(actionBtn('逃跑', 'dim', () => act('combat', { act: 'flee' })));
      bar.scrollLeft = 0;
      return;
    }

    bar.appendChild(actionBtn('查看四周', '', () => act('look')));
    bar.appendChild(actionBtn(me.resting ? '起身' : '休息', me.resting ? 'primary' : '', () => act('rest')));

    loc.containers.forEach(ct => {
      if (ct.left > 0) bar.appendChild(actionBtn(`搜·${ct.name}`.slice(0, 14), '', () => act('search', { key: ct.key })));
    });
    if (loc.forage) bar.appendChild(actionBtn('采集', '', () => act('forage')));

    loc.ground.forEach((g, i) => {
      if (i < 3) bar.appendChild(actionBtn(`拾·${g.name}`, '', () => act('pickup', { idx: i })));
    });
    loc.corpses.forEach((cp, i) => {
      bar.appendChild(actionBtn(`搜尸·${cp.name}`.slice(0, 12), 'dim', () => act('search_corpse', { idx: i })));
    });

    loc.npcs.forEach(n => {
      bar.appendChild(actionBtn(`交谈·${n.name}`, 'primary', () => openNpc(n.id)));
    });

    if (loc.others.length) {
      bar.appendChild(actionBtn(`组队(${loc.others.length})`, '', () => { sheetTab = 'team'; renderSheet(); }));
    }

    const r = view.world.rumor;
    if (r && r.loc === loc.id) bar.appendChild(actionBtn('追查传闻', 'primary', () => act('chase_rumor')));

    loc.exits.forEach(ex => {
      bar.appendChild(actionBtn(`→ ${ex.name} ${ex.cost}分`, 'dim', () => act('move', { to: ex.id })));
    });

    bar.scrollLeft = prev;
  }

  /* ---------------- 面板 ---------------- */
  function openNpc(id) {
    const npc = view.loc.npcs.find(n => n.id === id);
    if (!npc) return;
    sheetTab = 'npc:' + id;
    renderSheet();
  }

  function closeSheet() {
    sheetTab = null;
    $('#sheet').classList.add('hidden');
  }

  function setActiveTab(key) {
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === key));
  }

  function renderSheet() {
    if (!sheetTab) { $('#sheet').classList.add('hidden'); return; }
    const sheet = $('#sheet');
    const body = $('#sheetBody');
    sheet.classList.remove('hidden');
    lastSheetScroll = body.scrollTop;

    const me = view.me;
    const inv = view.inv;
    let title = '背包';
    let html = '';

    const invActionButtons = (item) => {
      const b = [];
      const t = item.type;
      if (['food', 'water', 'med', 'tool'].includes(t) || item.id === 'water_tab' || item.id === 'flashlight') {
        b.push(`<button class="mini gold" data-use="${item.id}">使用</button>`);
      }
      if (['weapon', 'armor', 'mask'].includes(t)) {
        b.push(`<button class="mini gold" data-equip="${item.id}">${item.eq ? '已装备' : '装备'}</button>`);
      }
      if (view.loc.isHideout) b.push(`<button class="mini" data-store="${item.id}">存入据点</button>`);
      if (view.loc.others.length) b.push(`<button class="mini" data-give="${item.id}">给队友</button>`);
      b.push(`<button class="mini red" data-drop="${item.id}">丢弃</button>`);
      return b.join('');
    };

    if (sheetTab === 'bag') {
      title = '背包 · ' + me.load + '/' + me.cap + 'kg';
      if (!inv.length) html += '<div class="empty">你身上什么都没有。</div>';
      inv.forEach(item => {
        const dec = item.dec != null ? ` · 还能放 ${item.dec} 小时` : '';
        html += `<div class="item-row">
          <div class="row-flex"><span class="item-name">${esc(item.name)}${item.qty > 1 ? ' ×' + item.qty : ''}${item.eq ? ' 〔已装备〕' : ''}</span><span class="item-meta">${item.w}kg</span></div>
          <div class="item-meta">${typeName(item.type)}${dec}</div>
          <div class="item-desc">${esc(item.desc || '')}</div>
          <div class="item-actions">${invActionButtons(item)}</div>
        </div>`;
      });
    } else if (sheetTab === 'attr') {
      title = '属性分配 · 剩余 ' + me.points;
      const attrs = [['str', '力量', '影响近战伤害、负重上限'], ['agi', '敏捷', '影响命中、闪避、逃跑成功率'], ['con', '体质', '影响生命上限、体力上限'], ['per', '感知', '影响发现与命中细节']];
      html = `<div class="attr-grid">${attrs.map(([k, n, d]) => `
        <div class="attr-box"><div class="attr-name">${n}</div><div class="attr-val">${me.attrs[k]}</div>
        <div class="item-meta">${d}</div>
        ${me.points > 0 ? `<button class="mini gold" data-attr="${k}">+1</button>` : ''}</div>`).join('')}</div>
        <div class="section-title">技能</div>
        <div class="item-meta">${Object.entries(me.skills).map(([k, v]) => `${skillName(k)} ${v}`).join(' · ')}</div>`;
    } else if (sheetTab === 'craft') {
      title = '制作';
      html += '<div class="section-title">随身制作</div>';
      view.recipes.forEach(r => {
        const needs = Object.entries(r.need).map(([id, q]) => {
          const have = countInv(id);
          return `<span class="${have >= q ? 'need-ok' : 'need-no'}">${esc(itemName(id))}×${q}(${have})</span>`;
        }).join('、');
        const ok = Object.entries(r.need).every(([id, q]) => countInv(id) >= q);
        html += `<div class="item-row">
          <div class="row-flex"><span class="item-name">${esc(r.name)}</span><span class="item-meta">${esc(r.out)}</span></div>
          <div class="need-list">需要：${needs}</div>
          <div class="item-desc">${esc(r.desc)}</div>
          <div class="item-actions"><button class="mini ${ok ? 'gold' : 'dis'}" data-craft="${r.id}">制作</button></div>
        </div>`;
      });
    } else if (sheetTab === 'base') {
      title = '据点';
      const h = view.hideout;
      if (!h.loc) {
        html = `<div class="empty">你还没有据点。</div>
          <div class="item-row"><div class="item-name">把当前地点设为据点</div>
          <div class="item-desc">据点可以存放物资、建造设施，也会在夜里被袭击。选一个你觉得安全的地方。</div>
          <div class="item-actions"><button class="mini gold" data-sethideout="1">在 ${esc(view.loc.name)} 安家</button></div></div>`;
      } else {
        html += `<div class="item-row"><div class="row-flex"><span class="item-name">${esc(h.locName)}</span>
          <span class="item-meta">${h.loc === view.loc.id ? '你在这里' : '不在此处'}</span></div>
          <div class="item-desc">已建：${h.buildings.length ? h.buildings.map(b => esc(buildingName(b))).join('、') : '什么都没有'}</div></div>`;
        if (h.loc !== view.loc.id) {
          html += `<div class="item-desc">回到据点后才能建造和存取物资。</div>`;
        }
        html += '<div class="section-title">可建造</div>';
        view.buildOptions.forEach(b => {
          const needs = Object.entries(b.need).map(([id, q]) => `<span class="${countInv(id) >= q ? 'need-ok' : 'need-no'}">${esc(itemName(id))}×${q}(${countInv(id)})</span>`).join('、');
          const built = b.built;
          const ok = !built && Object.entries(b.need).every(([id, q]) => countInv(id) >= q) && h.loc === view.loc.id;
          html += `<div class="item-row">
            <div class="row-flex"><span class="item-name">${esc(b.name)}</span><span class="item-meta">${built ? '已建' : ''}</span></div>
            <div class="need-list">${needs}</div>
            <div class="item-desc">${esc(b.desc)}</div>
            <div class="item-actions"><button class="mini ${ok ? 'gold' : 'dis'}" data-build="${b.id}">${built ? '已完成' : '建造'}</button></div>
          </div>`;
        });
        if (h.buildings.includes('campfire')) {
          html += '<div class="section-title">篝火</div>';
          view.campfireRecipes.forEach(r => {
            const needs = Object.entries(r.need).map(([id, q]) => `<span class="${countInv(id) >= q ? 'need-ok' : 'need-no'}">${esc(itemName(id))}×${q}</span>`).join('、');
            const ok = Object.entries(r.need).every(([id, q]) => countInv(id) >= q) && h.loc === view.loc.id;
            html += `<div class="item-row"><div class="row-flex"><span class="item-name">${esc(r.name)}</span></div>
              <div class="need-list">${needs}</div><div class="item-desc">${esc(r.desc)}</div>
              <div class="item-actions"><button class="mini ${ok ? 'gold' : 'dis'}" data-campfire="${r.id}">做</button></div></div>`;
          });
        }
        html += '<div class="section-title">储物处</div>';
        if (!h.storage.length) html += '<div class="empty">储物处是空的。</div>';
        h.storage.forEach(s => {
          html += `<div class="row"><div class="row-flex"><span>${esc(s.name)} ×${s.qty}</span>
            <button class="mini" data-take="${s.id}">取出</button></div></div>`;
        });
      }
    } else if (sheetTab === 'team') {
      title = '队伍';
      if (view.party.members.length) {
        html += '<div class="section-title">队员</div>';
        view.party.members.forEach(m => {
          html += `<div class="row"><div class="row-flex"><span>${esc(m.name)}${m.lead ? ' 〔队长〕' : ''}</span><span class="item-meta">${m.hp} HP · ${esc(m.loc)}</span></div>
            ${m.id !== me.id ? `<div class="item-actions">
              <button class="mini gold" data-bandage="${m.id}">包扎</button>
              ${view.hideout && m.loc === view.loc.name && view.loc.others.find(o => o.id === m.id) ? `<button class="mini red" data-attackplayer="${m.id}">背刺</button>` : ''}
            </div>` : ''}</div>`;
        });
        html += `<div class="item-actions"><button class="mini" data-partyleave="1">离开队伍</button></div>`;
      } else {
        html += '<div class="empty">你还没有队伍。同一地点的玩家可以邀请。</div>';
      }
      if (invite) {
        html += `<div class="item-row"><div class="item-name">${esc(invite.from)} 邀请你组队</div>
          <div class="item-actions"><button class="mini gold" data-partyaccept="${invite.fromId}">接受</button></div></div>`;
      }
      const others = view.loc.others;
      if (others.length) {
        html += '<div class="section-title">同一地点的人</div>';
        others.forEach(o => {
          html += `<div class="row"><div class="row-flex"><span>${esc(o.name)}${o.party ? ' 〔队友〕' : ''}</span><span class="item-meta">${o.hp} HP</span></div>
            <div class="item-actions">
              <button class="mini gold" data-invite="${o.id}">邀请组队</button>
              <button class="mini" data-bandage="${o.id}">包扎</button>
              <button class="mini red" data-attackplayer="${o.id}">偷袭</button>
              <button class="mini red" data-rob="${o.id}">抢夺</button>
            </div></div>`;
        });
      }
    } else if (sheetTab === 'world') {
      title = '世界';
      html += `<div class="item-row">
        <div class="row-flex"><span class="item-name">房间码 ${esc(view.world.room)}</span>
        <button class="mini gold" data-copy="1">复制</button></div>
        <div class="item-desc">把这个码发给朋友，他们打开同一个网址、输入房间码，就进入同一个世界。</div></div>`;
      html += `<div class="item-row"><div class="row-flex"><span>${esc(view.world.time)} · ${esc(view.world.weatherName)}</span><span class="item-meta">${view.world.online} 人在线</span></div></div>`;
      const r = view.world.rumor;
      if (r) {
        html += `<div class="item-row"><div class="item-name">〔传闻〕</div>
          <div class="item-desc">${esc(r.text)}</div>
          <div class="item-meta">地点：${esc(r.locName)}${r.loc === view.loc.id ? '（你就在这里）' : ''}</div></div>`;
      }
      html += `<div class="section-title">怎么玩</div>
        <div class="item-desc" style="margin-bottom:8px">
          ① 在「行动」栏搜索柜子、货架、尸体，收集食物、水、药品、材料。<br>
          ② 饥饿和口渴会持续下降，感染值到 100 会变异死亡，伤口出血会一直掉血。<br>
          ③ 危险等级越高的地方物资越好，也越容易遇到丧尸。<br>
          ④ 找个地方「设为据点」，建储物柜、篝火、围墙，夜里会被袭击。<br>
          ⑤ 和同房间玩家组队可以互相包扎、分摊物资，也可以偷袭抢东西。<br>
          ⑥ 死亡后可在据点复活（丢大部分物资），或删除角色重来。
        </div>`;
      html += '<div class="section-title">世界动态</div>';
      (view.world.feed || []).forEach(f => { html += `<div class="item-meta" style="margin-bottom:6px">${esc(f)}</div>`; });
      html += `<div class="section-title">角色</div>
        <div class="item-meta">击杀 ${me.kills} · 善恶 ${me.karma} · 房间 ${esc(view.world.room)}</div>
        <div class="item-actions"><button class="mini red" data-logout="1">离开房间</button></div>`;
    } else if (sheetTab.startsWith('npc:')) {
      const npc = view.loc.npcs.find(n => n.id === sheetTab.slice(4));
      if (!npc) { closeSheet(); return; }
      title = npc.name + ' · ' + kindName(npc.kind);
      html += `<div class="item-desc">${esc(npc.desc)}</div><div class="item-actions">
        <button class="mini gold" data-talk="${npc.id}">交谈</button>
        ${npc.kind === 'raider' ? `<button class="mini red" data-attacknpc="${npc.id}">先下手</button>` : ''}
        ${npc.quest && !npc.quest.claimed ? `<button class="mini ${npc.questReady ? 'gold' : 'dis'}" data-quest="${npc.id}">交付委托</button>` : ''}
      </div>`;
      if (npc.quest) {
        html += `<div class="item-row" style="margin-top:10px"><div class="item-name">〔委托〕${esc(npc.quest.title)}</div>
          <div class="item-desc">${esc(npc.quest.desc)}</div>
          <div class="need-list">需要 ${esc(npc.quest.need)} → 报酬 ${esc(npc.quest.reward)}</div>
          <div class="item-meta">${npc.quest.claimed ? '已完成' : npc.quest.claimable ? '东西齐了，可以交付' : '还没凑齐'}</div></div>`;
      }
      if (npc.stock && npc.stock.length) {
        html += '<div class="section-title">他的货</div>';
        npc.stock.forEach((s, i) => {
          const giveHint = inv.filter(it => Math.round(((it.w / it.qty) * 10 + 2) * it.qty) >= s.price)
            .map(it => it.name).slice(0, 3).join('、');
          html += `<div class="row"><div class="row-flex"><span>${esc(s.name)}</span><span class="item-meta">价值 ${s.price}</span></div>
            <div class="item-meta">可用：${esc(giveHint) || '没有够价的物资'}${inv.length > 3 ? '…' : ''}</div>
            <div class="item-actions"><button class="mini gold" data-trade="${npc.id}" data-idx="${i}">用物资换</button></div></div>`;
        });
      }
      if (npc.kind === 'raider') {
        html += `<div class="item-actions" style="margin-top:8px"><button class="mini red" data-attacknpc="${npc.id}">动手</button></div>`;
      }
    }

    $('#sheetTitle').textContent = title;
    body.innerHTML = html;
    body.scrollTop = lastSheetScroll;

    body.querySelectorAll('button[data-use]').forEach(b => b.onclick = () => { act('use', { item: b.dataset.use }); });
    body.querySelectorAll('button[data-equip]').forEach(b => b.onclick = () => { act('equip', { item: b.dataset.equip }); });
    body.querySelectorAll('button[data-drop]').forEach(b => b.onclick = () => { act('drop', { item: b.dataset.drop, qty: 1 }); });
    body.querySelectorAll('button[data-store]').forEach(b => b.onclick = () => { act('store', { item: b.dataset.store, qty: 1 }); });
    body.querySelectorAll('button[data-take]').forEach(b => b.onclick = () => { act('take', { item: b.dataset.take, qty: 1 }); });
    body.querySelectorAll('button[data-craft]').forEach(b => b.onclick = () => { act('craft', { recipe: b.dataset.craft }); });
    body.querySelectorAll('button[data-campfire]').forEach(b => b.onclick = () => { act('campfire', { recipe: b.dataset.campfire }); });
    body.querySelectorAll('button[data-build]').forEach(b => b.onclick = () => { act('build', { building: b.dataset.build }); });
    body.querySelectorAll('button[data-sethideout]').forEach(b => b.onclick = () => { act('set_hideout'); });
    body.querySelectorAll('button[data-attr]').forEach(b => b.onclick = () => { act('attribute', { attr: b.dataset.attr }); });
    body.querySelectorAll('button[data-invite]').forEach(b => b.onclick = () => { act('party', { op: 'invite', target: b.dataset.invite }); });
    body.querySelectorAll('button[data-partyaccept]').forEach(b => b.onclick = () => { act('party', { op: 'accept', from: b.dataset.partyaccept }); invite = null; });
    body.querySelectorAll('button[data-partyleave]').forEach(b => b.onclick = () => { act('party', { op: 'leave' }); });
    body.querySelectorAll('button[data-bandage]').forEach(b => b.onclick = () => { act('pvp', { op: 'bandage', target: b.dataset.bandage }); });
    body.querySelectorAll('button[data-attackplayer]').forEach(b => b.onclick = () => { if (confirm('偷袭同房间玩家？这会结仇。')) act('pvp', { op: 'attack', target: b.dataset.attackplayer }); });
    body.querySelectorAll('button[data-rob]').forEach(b => b.onclick = () => { act('pvp', { op: 'rob', target: b.dataset.rob }); });
    body.querySelectorAll('button[data-talk]').forEach(b => b.onclick = () => { act('talk', { npc: b.dataset.talk }); });
    body.querySelectorAll('button[data-quest]').forEach(b => b.onclick = () => { act('quest', { npc: b.dataset.quest }); });
    body.querySelectorAll('button[data-attacknpc]').forEach(b => b.onclick = () => { if (confirm('对他动手？')) act('attack_npc', { npc: b.dataset.attacknpc }); });
    body.querySelectorAll('button[data-trade]').forEach(b => b.onclick = () => { openTradePick(b.dataset.trade, Number(b.dataset.idx)); });
    body.querySelectorAll('button[data-give]').forEach(b => b.onclick = () => { openGivePick(b.dataset.give); });
    body.querySelectorAll('button[data-copy]').forEach(b => b.onclick = () => {
      const code = view.world.room;
      navigator.clipboard ? navigator.clipboard.writeText(code).then(() => toast('房间码已复制：' + code)) : toast('房间码：' + code);
    });
    body.querySelectorAll('button[data-logout]').forEach(b => b.onclick = () => {
      localStorage.removeItem('mud_token');
      location.reload();
    });
  }

  function openTradePick(npcId, idx) {
    const npc = view.loc.npcs.find(n => n.id === npcId);
    if (!npc) return;
    const stock = npc.stock[idx];
    const body = $('#sheetBody');
    let html = `<div class="item-row"><div class="item-name">换：${esc(stock.name)}</div>
      <div class="item-meta">他要求价值 ${stock.price} 的物资</div></div>
      <div class="section-title">用你身上的东西换</div>`;
    if (!view.inv.length) html += '<div class="empty">你身上没有可交换的东西。</div>';
    view.inv.forEach(item => {
      const unit = item.w / item.qty;
      const val = Math.round((unit * 10 + 2) * item.qty);
      const ok = val >= stock.price;
      html += `<div class="row"><div class="row-flex"><span>${esc(item.name)} ×${item.qty}</span>
        <span class="item-meta">约值 ${val}</span></div>
        <div class="item-actions"><button class="mini ${ok ? 'gold' : 'dis'}" data-tradego="${item.id}">${ok ? '交换' : '不够值'}</button></div></div>`;
    });
    $('#sheetTitle').textContent = '以物易物';
    body.innerHTML = html;
    body.querySelectorAll('button[data-tradego]').forEach(b => b.onclick = () => {
      act('trade', { npc: npcId, takeIdx: idx, giveId: b.dataset.tradego, giveQty: 1 });
      sheetTab = 'npc:' + npcId;
      setTimeout(renderSheet, 300);
    });
  }

  function openGivePick(itemId) {
    const body = $('#sheetBody');
    const others = view.loc.others;
    let html = `<div class="item-row"><div class="item-name">给出：${esc(itemName(itemId))}</div></div>`;
    others.forEach(o => {
      html += `<div class="row"><div class="row-flex"><span>${esc(o.name)}</span>
        <button class="mini gold" data-giveto="${o.id}">给他</button></div></div>`;
    });
    $('#sheetTitle').textContent = '交给谁';
    body.innerHTML = html;
    body.querySelectorAll('button[data-giveto]').forEach(b => b.onclick = () => {
      act('give', { target: b.dataset.giveto, item: itemId, qty: 1 });
      sheetTab = 'bag';
      setTimeout(renderSheet, 300);
    });
  }

  /* ---------------- 工具 ---------------- */
  function countInv(id) {
    if (!view) return 0;
    return view.inv.filter(s => s.id === id).reduce((a, b) => a + b.qty, 0);
  }
  const NAME_CACHE = {};
  function itemName(id) {
    if (NAME_CACHE[id]) return NAME_CACHE[id];
    const it = (view.inv || []).find(s => s.id === id);
    if (it) { NAME_CACHE[id] = it.name; return it.name; }
    const map = {
      cloth: '布料', alcohol: '消毒酒精', plank: '木板', nail: '铁钉', tape: '胶带', rope: '绳索',
      bat: '棒球棍', charcoal: '活性炭', bottle_empty: '空瓶', gasoline: '汽油', screwdriver: '螺丝刀',
      brick: '砖块', lighter: '打火机', trap_kit: '陷阱套件', wire: '电线', battery: '电池', spring: '弹簧',
      dirty: '脏水', water: '净水', raw_meat: '生肉', rice: '大米', bandage: '绷带', pistol_ammo: '手枪弹',
    };
    return map[id] || id;
  }
  function typeName(t) {
    return ({ food: '食物', water: '饮水', med: '药品', material: '材料', part: '零件', ammo: '弹药', weapon: '武器', armor: '护具', mask: '面罩', tool: '工具', fuel: '燃料', battery: '电池', throwable: '投掷物', misc: '杂物' })[t] || '物品';
  }
  function skillName(k) {
    return ({ firstaid: '急救', stealth: '潜行', firearms: '枪械', forge: '锻造', scout: '侦查', melee: '近战' })[k] || k;
  }
  function kindName(k) {
    return ({ trader: '商人', medic: '医生', orderly: '守序者', scavenger: '拾荒者', raider: '掠夺者' })[k] || '幸存者';
  }
  function buildingName(k) {
    return ({ workbench: '工作台', campfire: '篝火', wall: '围墙', trap: '陷阱', shelter: '避难屋', storage: '储物柜', alarm: '警戒装置' })[k] || k;
  }

  /* ---------------- 交互绑定 ---------------- */
  $('#btnJoin').onclick = () => {
    const name = $('#inName').value.trim();
    const code = $('#inRoom').value.trim().toUpperCase();
    if (!name) return showLoginMsg('先给自己起个名字。');
    if (!code) return showLoginMsg('输入房间码，或者点「创建新房间」。');
    myName = name;
    connect(code, name, false);
  };
  $('#btnCreate').onclick = () => {
    const name = $('#inName').value.trim();
    if (!name) return showLoginMsg('先给自己起个名字。');
    myName = name;
    fetch('/api/create').then(r => r.json()).then(d => {
      if (d && d.code) {
        $('#inRoom').value = d.code;
        connect(d.code, name, true);
      }
    }).catch(() => showLoginMsg('创建房间失败，刷新页面重试。'));
  };
  function showLoginMsg(t) { $('#loginMsg').textContent = t; }

  $('#inName').value = myName;
  if (currentRoom) $('#inRoom').value = currentRoom;

  $('#btnMenu').onclick = () => { sheetTab = 'world'; renderSheet(); };
  $('#sheetClose').onclick = closeSheet;
  $('#chatSend').onclick = () => {
    const v = $('#chatInput').value.trim();
    if (!v || !view) return;
    act('chat', { text: v, ch: $('#chatCh').value });
    $('#chatInput').value = '';
  };
  $('#chatInput').addEventListener('keydown', e => { if (e.key === 'Enter') $('#chatSend').click(); });

  document.querySelectorAll('.tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      if (tab.dataset.tab === 'act') { closeSheet(); tab.classList.add('active'); return; }
      tab.classList.add('active');
      sheetTab = tab.dataset.tab;
      renderSheet();
    };
  });

  $('#btnRevive').onclick = () => act('revive');
  $('#btnDelete').onclick = () => {
    if (confirm('确定删除角色？所有进度都会消失。')) act('delete_char');
  };

  // 死亡后按钮
  $('#deathScreen').addEventListener('click', e => {
    if (e.target.id === 'btnRevive') $('#deathScreen').classList.add('hidden');
    if (e.target.id === 'btnDelete') $('#deathScreen').classList.add('hidden');
  });

  // 有存档则自动回到房间
  if (token && currentRoom && myName) {
    $('#loginMsg').textContent = '正在回到房间 ' + currentRoom + ' …';
    setTimeout(() => connect(currentRoom, myName, false), 300);
  }

  // 心跳
  setInterval(() => { if (ws && ws.readyState === 1) send({ t: 'ping' }); }, 25000);
  window.addEventListener('beforeunload', () => { if (ws) ws.close(); });
})();
