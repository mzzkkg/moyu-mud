'use strict';
/**
 * 制作配方与据点建筑
 */
const RECIPES = [
  { id: 'bandage_make', name: '裁制绷带', need: { cloth: 2, alcohol: 1 }, out: { bandage: 2 }, time: 10, skill: 'firstaid', desc: '把布条剪成两指宽，泡过酒精再晾干。' },
  { id: 'spear_make', name: '自制长矛', need: { plank: 1, nail: 2, tape: 1 }, out: { spear: 1 }, time: 20, skill: 'forge', desc: '磨尖的钉子绑在木杆前端，长度够你在丧尸够到你之前捅穿它的喉咙。' },
  { id: 'nailbat_make', name: '钉锤', need: { bat: 1, nail: 4, tape: 1 }, out: { nailbat: 1 }, time: 25, skill: 'forge', desc: '把长钉一根根钉进球棍，钉尖朝外，缠上胶带固定。' },
  { id: 'padarmor_make', name: '自制护具', need: { cloth: 3, tape: 2, plank: 1 }, out: { padarmor: 1 }, time: 30, skill: 'forge', desc: '把木板削成片，缝进帆布，绑在胸口和手臂上。重，但能挡住牙。' },
  { id: 'gasmask_make', name: '简易防毒面罩', need: { cloth: 2, tape: 2, charcoal: 1 }, out: { gasmask: 1 }, time: 30, skill: 'forge', desc: '活性炭塞进塑料瓶，接上布罩，用胶带封住接缝。挡不住所有东西，但能挡一部分。' },
  { id: 'molotov_make', name: '燃烧瓶', need: { bottle_empty: 1, gasoline: 1, cloth: 1 }, out: { molotov: 1 }, time: 10, skill: 'forge', desc: '汽油灌进瓶子，布条塞住瓶口。点着扔出去，能烧穿一小片区域。' },
  { id: 'water_tab_make', name: '简易净水粉', need: { charcoal: 1, cloth: 1 }, out: { water_tab: 2 }, time: 15, skill: 'firstaid', desc: '把活性炭磨碎，混进少量漂白粉。' },
  { id: 'splint_make', name: '夹板', need: { plank: 1, cloth: 2, tape: 1 }, out: { splint: 1 }, time: 10, skill: 'firstaid', desc: '两块木板夹住断骨，用布条和胶带固定。' },
  { id: 'trap_make', name: '简易陷阱', need: { plank: 2, nail: 4, rope: 2 }, out: { trap_kit: 1 }, time: 30, skill: 'forge', desc: '一组带钉的木板与绳套，埋在门口，踩上去就收不回来了。' },
  { id: 'ammo_make', name: '复装手枪弹', need: { pistol_ammo: 2, screw: 1 }, out: { pistol_ammo: 3 }, time: 15, skill: 'firearms', desc: '拆开两发，重新配比火药，压进弹壳。有炸膛的风险。' },
];

const BUILDINGS = {
  workbench: { name: '工作台', need: { plank: 4, nail: 6, screwdriver: 1 }, time: 40, desc: '木架配铁台面，制作东西时不再只能蹲在地上。' },
  campfire: { name: '篝火', need: { plank: 3, lighter: 1, brick: 2 }, time: 20, desc: '火堆能烧水、烤肉、取暖，也能在黑夜里招来不该来的东西。' },
  wall: { name: '简易围墙', need: { plank: 6, nail: 10, brick: 4 }, time: 60, desc: '围住据点的一圈木板与砖，能拖慢丧尸潮的脚步。' },
  trap: { name: '警戒陷阱', need: { trap_kit: 1 }, time: 20, desc: '带钉的木板与绊索，夜里替你看门。' },
  shelter: { name: '临时避难屋', need: { plank: 10, rope: 4, cloth: 4 }, time: 90, desc: '一个能锁门的木棚，睡觉时不必睁着一只眼。' },
  storage: { name: '储物柜', need: { plank: 4, nail: 4 }, time: 30, desc: '据点里可以存放物资的铁皮柜。' },
  alarm: { name: '警戒装置', need: { wire: 2, battery: 1, spring: 2 }, time: 30, desc: '一圈细线接上电池，有人或什么东西碰断线，就会响。' },
};

const CAMPFIRE_RECIPES = [
  { id: 'boil', name: '煮沸脏水', need: { dirty: 1 }, out: { water: 1 }, time: 15, desc: '把脏水倒进铁盒，烧到翻滚，细菌和病毒都会死一批。' },
  { id: 'cook_meat', name: '烤肉', need: { raw_meat: 1 }, out: { cooked_meat: 1 }, time: 20, desc: '肉在火上滋滋作响，油脂滴下去，火苗窜起来。' },
  { id: 'cook_rice', name: '煮粥', need: { rice: 1, water: 1 }, out: { cooked_rice: 1 }, time: 25, desc: '一把米，一壶水，熬成一锅能顶半天的粥。' },
];

module.exports = { RECIPES, BUILDINGS, CAMPFIRE_RECIPES };
