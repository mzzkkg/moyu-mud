'use strict';
/**
 * 物品总表
 * type: food / water / med / material / part / ammo / weapon / armor / mask / tool / fuel / battery / throwable
 * w: 单件重量(kg)   dec: 腐烂时间(游戏小时，仅食物饮水)
 * eff: 食用效果 {hunger,thirst,hp,infection,sanity,pain,stamina}
 * med: 治疗 {injury:'laceration', amount:3} 或 {stopBleed:true}
 */
const ITEMS = {
  // ---------- 食物 ----------
  can:       { name: '午餐肉罐头', type: 'food', w: 0.4, dec: 2160, eff: { hunger: 38, sanity: 2 }, desc: '铁皮上印着模糊的保质期，油花在罐口结成一层白霜。' },
  canned_fruit: { name: '糖水黄桃罐头', type: 'food', w: 0.5, dec: 2160, eff: { hunger: 22, thirst: 12, sanity: 5 }, desc: '甜得发腻的糖水，末世里最接近"幸福"的味道。' },
  biscuit:   { name: '压缩饼干', type: 'food', w: 0.15, dec: 4320, eff: { hunger: 22, thirst: -4 }, desc: '咬一口满嘴干粉，得配水才能咽下去。' },
  noodle:    { name: '方便面', type: 'food', w: 0.1, dec: 1440, eff: { hunger: 26, thirst: -6 }, desc: '面饼碎了半袋，调料包还在。' },
  mre:       { name: '军用口粮', type: 'food', w: 0.6, dec: 8760, eff: { hunger: 65, sanity: 6, stamina: 15 }, desc: '铝箔袋里还有加热片，部队配发的那种。' },
  wild_berry:{ name: '野果', type: 'food', w: 0.05, dec: 36, eff: { hunger: 12, thirst: 6, infection: 2 }, desc: '酸涩的小果子，不确定有没有毒。' },
  raw_meat:  { name: '生肉', type: 'food', w: 0.5, dec: 18, eff: { hunger: 25, infection: 12, sanity: -3 }, desc: '血水顺着指缝滴下来，生吃等于给病毒开门。' },
  cooked_meat:{ name: '烤熟的肉', type: 'food', w: 0.4, dec: 48, eff: { hunger: 45, sanity: 5 }, desc: '焦香混着烟味，至少这次不会拉肚子。' },
  rice:      { name: '大米', type: 'food', w: 1.0, dec: 4320, eff: { hunger: 28, thirst: -5 }, desc: '生米，最好煮成粥。' },

  // ---------- 饮水 ----------
  water:     { name: '净水', type: 'water', w: 0.6, eff: { thirst: 48 }, desc: '瓶身贴着"已净化"的胶带，是别人留下的善意。' },
  bottled:   { name: '瓶装水', type: 'water', w: 0.6, eff: { thirst: 38 }, desc: '未开封，塑料瓶被晒得微微变形。' },
  dirty:     { name: '脏水', type: 'water', w: 0.6, eff: { thirst: 30, infection: 18, sanity: -2 }, desc: '水里有细小的悬浮物在打转。' },
  rainwater: { name: '雨水', type: 'water', w: 0.5, eff: { thirst: 26, infection: 6 }, desc: '接在铁桶里，表面浮着灰。' },
  water_tab: { name: '净水片', type: 'med', w: 0.02, eff: { thirst: 0 }, use: 'purify', desc: '丢进脏水里，半小时后能喝。' },

  // ---------- 药品 ----------
  bandage:   { name: '绷带', type: 'med', w: 0.1, med: { stopBleed: true, heal: 8 }, desc: '还算干净的纱布卷，止血是第一位的。' },
  hemostat:  { name: '止血粉', type: 'med', w: 0.05, med: { stopBleed: true, heal: 4 }, desc: '撒上去像被烙铁烫了一下，但血会停。' },
  antibiotics:{ name: '抗生素', type: 'med', w: 0.05, eff: { infection: -38 }, desc: '铝箔板只剩三粒，救命的玩意儿。' },
  painkiller:{ name: '止痛药', type: 'med', w: 0.03, eff: { pain: -65, hp: 4, sanity: 3 }, desc: '白色小药片，能让人暂时忘记自己在疼。' },
  vaccine:   { name: '疫苗残剂', type: 'med', w: 0.08, eff: { infection: -62, sanity: -8 }, desc: '冷链早断了，针剂浑浊，只能赌一把。' },
  alcohol:   { name: '消毒酒精', type: 'med', w: 0.3, eff: { infection: -14, pain: -10 }, desc: '刺鼻的工业酒精味，也能当引火物。' },
  splint:    { name: '夹板', type: 'med', w: 0.8, med: { injury: 'fracture', amount: 9 }, desc: '两块木板加绷带，固定住断骨。' },
  suture:    { name: '缝合包', type: 'med', w: 0.15, med: { injury: 'laceration', amount: 12, stopBleed: true }, desc: '弯针与线，缝合时最好有个人按住你。' },

  // ---------- 材料 / 零件 ----------
  plank:     { name: '木板', type: 'material', w: 2.0, desc: '从废弃家具上拆下来的，还能用。' },
  nail:      { name: '铁钉', type: 'material', w: 0.04, desc: '一把生锈的长钉，扎进木板里就是凶器。' },
  brick:     { name: '砖块', type: 'material', w: 2.5, desc: '半截红砖，棱角能砸开颅骨。' },
  cloth:     { name: '布料', type: 'material', w: 0.3, desc: '从窗帘或尸衣上剪下的一条。' },
  rope:      { name: '绳索', type: 'material', w: 0.6, desc: '六米长的尼龙绳，打着死结。' },
  tape:      { name: '胶带', type: 'material', w: 0.2, desc: '灰色宽胶带，能缠住一切，包括伤口。' },
  gear:      { name: '齿轮', type: 'part', w: 0.2, desc: '从电机里拆下的传动齿轮。' },
  spring:    { name: '弹簧', type: 'part', w: 0.1, desc: '有弹性的钢丝圈，陷阱的关键。' },
  wire:      { name: '电线', type: 'part', w: 0.3, desc: '铜芯还没断，可以接电池。' },
  screw:     { name: '螺丝', type: 'part', w: 0.02, desc: '满满一小盒，十字口。' },
  charcoal:  { name: '活性炭', type: 'material', w: 0.2, desc: '从净水器里倒出来的黑颗粒。' },

  // ---------- 弹药 ----------
  pistol_ammo:{ name: '手枪弹', type: 'ammo', w: 0.015, desc: '9mm，黄铜壳还亮着。' },
  rifle_ammo:{ name: '步枪弹', type: 'ammo', w: 0.02, desc: '5.56mm，弹匣里的剩货。' },
  shell:     { name: '霰弹', type: 'ammo', w: 0.03, desc: '红色塑料壳，一把钢珠。' },

  // ---------- 武器 ----------
  fists:     { name: '空手', type: 'weapon', w: 0, dmg: [3, 7], acc: 0, noise: 1, skill: 'melee', desc: '一无所有的时候，至少还有拳头。' },
  pipe:      { name: '铁管', type: 'weapon', w: 1.2, dmg: [8, 13], acc: 0.02, noise: 3, skill: 'melee', desc: '半米长的镀锌管，沉甸甸的。' },
  bat:       { name: '棒球棍', type: 'weapon', w: 0.9, dmg: [10, 16], acc: 0.0, noise: 4, skill: 'melee', desc: '铝制球棍，握柄缠着旧胶带。' },
  knife:     { name: '匕首', type: 'weapon', w: 0.3, dmg: [9, 15], acc: 0.06, noise: 1, skill: 'melee', bleed: 0.25, desc: '刃口有缺口，但足够刺进脖子。' },
  machete:   { name: '砍刀', type: 'weapon', w: 0.9, dmg: [13, 20], acc: 0.02, noise: 2, skill: 'melee', bleed: 0.2, desc: '开山刀，刀背厚，砍骨不卷刃。' },
  axe:       { name: '消防斧', type: 'weapon', w: 2.4, dmg: [16, 26], acc: -0.04, noise: 5, skill: 'melee', armorPierce: 2, desc: '红色斧身，斧刃上还挂着干涸的暗色。' },
  spear:     { name: '自制长矛', type: 'weapon', w: 1.6, dmg: [12, 19], acc: 0.03, noise: 2, skill: 'melee', firstStrike: true, desc: '磨尖的钢筋绑在木杆上，够长。' },
  nailbat:   { name: '钉锤', type: 'weapon', w: 1.4, dmg: [13, 19], acc: -0.02, noise: 4, skill: 'melee', bleed: 0.15, armorPierce: 1, desc: '球棍上钉满长钉，像一只铁刺猬。' },
  crowbar:   { name: '撬棍', type: 'weapon', w: 1.8, dmg: [10, 15], acc: 0.0, noise: 3, skill: 'melee', tool: true, desc: '能撬锁，也能撬开头骨。' },
  pistol:    { name: '手枪', type: 'weapon', w: 0.9, dmg: [14, 21], acc: 0.05, noise: 9, skill: 'firearms', ammo: 'pistol_ammo', desc: '枪身编号被锉掉了，膛线还在。' },
  shotgun:   { name: '猎枪', type: 'weapon', w: 3.0, dmg: [26, 40], acc: -0.04, noise: 12, skill: 'firearms', ammo: 'shell', desc: '双管猎枪，木托被磨得发亮。' },
  rifle:     { name: '步枪', type: 'weapon', w: 3.4, dmg: [22, 32], acc: 0.08, noise: 11, skill: 'firearms', ammo: 'rifle_ammo', desc: '制式步枪，弹匣里压着五发。' },

  // ---------- 防具 ----------
  jacket:    { name: '皮夹克', type: 'armor', w: 3, armor: 2, desc: '厚牛皮，至少能挡住牙。' },
  padarmor:  { name: '自制护具', type: 'armor', w: 4.5, armor: 3, desc: '钢板缝在帆布里，绑在胸口和手臂上。' },
  vest:      { name: '防弹背心', type: 'armor', w: 8, armor: 6, desc: '插板还在，能挡子弹的那种。' },
  helmet:    { name: '防暴头盔', type: 'armor', w: 1.6, armor: 2, slot: 'head', desc: '面罩裂了一道，但护住了颅骨。' },
  gasmask:   { name: '简易防毒面罩', type: 'mask', w: 1.2, protect: 0.45, desc: '自制滤毒罐，能把感染气溶胶挡下一半。' },

  // ---------- 燃料 / 电池 / 工具 ----------
  gasoline:  { name: '汽油', type: 'fuel', w: 3.0, desc: '装在塑料桶里，挥发得很快。' },
  diesel:    { name: '柴油', type: 'fuel', w: 3.2, desc: '柴油发电机还认这个。' },
  battery:   { name: '电池', type: 'battery', w: 0.05, desc: '两节五号，电压还剩一半。' },
  car_battery:{ name: '汽车电瓶', type: 'battery', w: 12, desc: '沉得像块石头，但能供电。' },
  lighter:   { name: '打火机', type: 'tool', w: 0.03, desc: '砂轮一擦就着，火苗很小。' },
  flashlight:{ name: '手电', type: 'tool', w: 0.3, desc: '铝壳手电，光柱能切开黑暗。' },
  radio:     { name: '收音机', type: 'tool', w: 0.4, desc: '调频指针停在某个频率上，偶尔有杂音。' },
  binocular: { name: '望远镜', type: 'tool', w: 0.5, desc: '八倍，镜片有霉点。' },
  screwdriver:{ name: '螺丝刀', type: 'tool', w: 0.1, desc: '十字头，也能当锥子。' },
  shovel:    { name: '工兵铲', type: 'tool', w: 1.2, dmg: [8, 12], acc: 0, noise: 3, skill: 'melee', tool: true, desc: '折叠铲，能挖坑也能砍。' },
  bottle_empty:{ name: '空瓶', type: 'material', w: 0.1, desc: '拧紧盖子的塑料瓶，可以装水。' },

  // ---------- 投掷物 ----------
  molotov:   { name: '燃烧瓶', type: 'throwable', w: 0.6, dmg: [18, 30], desc: '布条塞在瓶口，点着就能扔。' },

  // ---------- 其它 ----------
  medkit:    { name: '急救包', type: 'med', w: 1.0, med: { stopBleed: true, heal: 25, injury: 'all', amount: 3 }, desc: '红十字会发放的红色帆布包，里面还算齐。' },
  cooked_rice:{ name: '热粥', type: 'food', w: 0.4, dec: 24, eff: { hunger: 42, thirst: 10, sanity: 6 }, desc: '一碗稠粥，热气糊了满脸。' },
  trap_kit:  { name: '陷阱套件', type: 'material', w: 2.5, desc: '带钉木板与绊索捆在一起，安装需要场地。' },
  note:      { name: '字条', type: 'misc', w: 0.01, desc: '有人留下的字。' },
  dogtag:    { name: '狗牌', type: 'misc', w: 0.02, desc: '两片铝牌，上面刻着名字和血型。' },
  fuel_can:  { name: '柴油桶', type: 'fuel', w: 6, desc: '二十升装，桶身凹陷。' },
};

function itemDef(id) {
  return ITEMS[id] || { name: '未知物品', type: 'misc', w: 0.1, desc: '' };
}

/** 计算一堆物品的总重量 */
function stackWeight(id, qty) {
  return itemDef(id).w * qty;
}

module.exports = { ITEMS, itemDef, stackWeight };
