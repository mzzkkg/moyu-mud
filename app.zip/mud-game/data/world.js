'use strict';
/**
 * 世界地图：16 个地点。
 * exits: 相邻地点与路程(游戏分钟)，脚本会自动生成反向通道。
 */
const LOCATIONS = {
  jiezi: {
    name: '建设路 · 十字路口',
    danger: 1, type: 'urban',
    desc: '柏油路面裂开一道两指宽的缝，缝里长出了半人高的野草。十字路口四角的红绿灯全都黑着，只有一盏还在闪黄，像只不肯闭上的眼睛。风卷着传单和塑料袋滚过斑马线，一排车横七竖八地堵在路中间，车门大开，里面早就空了。',
    flavor: [
      '远处一栋居民楼的玻璃幕墙整片塌了下来，风一过，碎玻璃像雨一样哗啦作响。',
      '路边的公交站牌上贴满了寻人启事，纸角被雨水泡烂，名字只剩下半个。',
      '一辆救护车侧翻在路中央，后门敞着，担架滑出来一半，上面落满了灰。',
    ],
    exits: { chaoshi: 12, yiyuan: 20, gongyu: 15, xuexiao: 18, jiayouzhan: 25 },
    containers: [
      { key: 'car1', name: '翻倒的白色轿车', loot: 'car', cap: 3 },
      { key: 'bus', name: '抛锚的公交车', loot: 'junk', cap: 3 },
      { key: 'shop', name: '卷帘门半开的杂货铺', loot: 'market', cap: 2 },
    ],
    forage: { table: 'junk', max: 1 },
  },

  chaoshi: {
    name: '永辉超市 · 城北店',
    danger: 2, type: 'urban',
    desc: '超市的自动门停在半开的位置，门缝里卡着一只购物车。应急灯还亮着，惨白的光照着一排排空货架。收银台前的传送带上留着几盒口香糖，价格标签在风里轻轻翻动。空气里是消毒水、腐烂食物和铁锈混在一起的味道。',
    flavor: [
      '生鲜区的冷柜早断电了，玻璃上蒙着一层厚霜，里面黑黢黢的看不清。',
      '地上一道长长的拖行痕迹，从收银台一直延伸向后仓，像是有什么东西被拖走了。',
      '广播喇叭偶尔冒出一句失真的"请顾客……"，然后就没了声音。',
    ],
    exits: { jiezi: 12, cangku: 18 },
    containers: [
      { key: 'a', name: '零食货架（第一排）', loot: 'market', cap: 3 },
      { key: 'b', name: '饮料货架（第二排）', loot: 'market', cap: 3 },
      { key: 'c', name: '生鲜冷柜', loot: 'freezer', cap: 2 },
      { key: 'd', name: '后仓铁门后的仓库', loot: 'market', cap: 4 },
    ],
    forage: { table: 'junk', max: 2 },
  },

  yiyuan: {
    name: '市第三人民医院 · 门诊楼',
    danger: 4, type: 'medical',
    desc: '门诊大厅的候诊椅上，还坐着几个"病人"——它们低着头，一动不动，像在等一个永远不会叫到的号。地砖上拖出十几条褐色的痕迹，通向不同的诊室。挂号窗口的玻璃碎了，里面的电脑屏幕还亮着待机灯，一闪一闪。',
    flavor: [
      '输液架上挂着一袋发黄的液体，管子里最后一滴悬在那里，始终没落下来。',
      '某个诊室里传来指甲刮门的声音，一下，两下，很有耐心。',
      '走廊尽头的安全出口指示灯绿得反常，映得整条走廊像泡在水里。',
    ],
    exits: { jiezi: 20, gongyu: 12, ditie: 22 },
    containers: [
      { key: 'a', name: '急诊室储物柜', loot: 'hospital', cap: 4 },
      { key: 'b', name: '药房取药窗口', loot: 'pharmacy', cap: 3 },
      { key: 'c', name: '三楼手术室', loot: 'hospital', cap: 2 },
      { key: 'd', name: '负一层停尸房', loot: 'morgue', cap: 2 },
    ],
    forage: { table: 'clinic_small', max: 2 },
  },

  jingju: {
    name: '城东分局 · 警察局',
    danger: 4, type: 'police',
    desc: '警局的铁栅门被撞开了，门框上的蓝白标识掉了一半油漆。值班台后面，一面挂满警徽的墙被砸出个洞。地上的警戒线还拉在半人高处，黄色塑料带在风里抖，写着"警察办案 禁止跨越"。',
    flavor: [
      '证据室里散落着一地卷宗，照片上的脸全被雨水泡成了一团。',
      '走廊地面有几道深褐色的抓痕，像是指甲硬生生犁出来的。',
      '枪柜旁的地上有一枚弹壳，铜壳已经氧化成暗绿色。',
    ],
    exits: { jiezi: 16, shoufeizhan: 30, ditie: 25 },
    containers: [
      { key: 'a', name: '枪械柜（编号 07）', loot: 'police', cap: 2 },
      { key: 'b', name: '值班台抽屉', loot: 'office', cap: 3 },
      { key: 'c', name: '证物档案室', loot: 'office', cap: 3 },
      { key: 'd', name: '地下车库巡逻车', loot: 'car', cap: 2 },
    ],
    forage: { table: 'junk', max: 2 },
  },

  ditie: {
    name: '地铁一号线 · 二号隧道',
    danger: 5, type: 'underground',
    desc: '隧道里没有一丝风，手电的光柱被黑暗吞掉一半。铁轨上有积水，反着微弱的光。一列列车停在两百米外，车厢门开着一道缝。远处传来金属摩擦的声音，很有节奏，像是有人在铁轨上拖着什么走。',
    flavor: [
      '头顶的应急灯每隔十秒亮一次，照亮墙上用血写着的一个数字：37。',
      '车厢里传来很轻的敲击声，三下，停一下，再三下。',
      '水流声来自更深的岔道，那里黑得连手电都照不穿。',
    ],
    exits: { yiyuan: 22, jingju: 25, bihansuo: 20 },
    containers: [
      { key: 'a', name: '失事列车的行李架', loot: 'metro', cap: 3 },
      { key: 'b', name: '检修间的工具柜', loot: 'garage', cap: 2 },
      { key: 'c', name: '应急物资箱（红色）', loot: 'metro', cap: 1 },
    ],
    forage: { table: 'metro', max: 2 },
  },

  senlin: {
    name: '北郊 · 松岭林场',
    danger: 2, type: 'forest',
    desc: '松针铺了厚厚一层，踩上去几乎没有声音。树干上留着几道深深的爪痕，从地面一直爬到两米高的地方。林间空地上有一堆熄灭的篝火，灰烬里埋着几根骨头，不像动物的。',
    flavor: [
      '风穿过树冠，声音像有人在很远的地方压低嗓子说话。',
      '一只乌鸦停在枯枝上，歪头看你，很久都不飞。',
      '灌木丛里有东西快速掠过，草叶晃动了两下就归于平静。',
    ],
    exits: { nongchang: 25, xuexiao: 20, matou: 30, ditan: 35 },
    containers: [
      { key: 'a', name: '猎户小屋的木箱', loot: 'hunter', cap: 3 },
      { key: 'b', name: '溪边的废弃营地', loot: 'forest', cap: 3 },
      { key: 'c', name: '树上钉着的铁皮箱', loot: 'hunter', cap: 1 },
    ],
    forage: { table: 'forest', max: 3 },
  },

  nongchang: {
    name: '青禾农场',
    danger: 1, type: 'farm',
    desc: '稻田早已荒了，稻穗倒伏在黑泥里，发出酸腐的甜味。谷仓的门开着，里面堆着半屋子发霉的谷袋。院子里一口水井，井绳还垂在井沿上，末端系着的木桶不见了。',
    flavor: [
      '鸡舍里只剩下几根羽毛，铁丝网被撕开一个能钻过人的洞。',
      '远处的风车叶片卡住了，歪着头停在半空。',
      '拖拉机驾驶室里坐着一具干瘪的躯体，手还搭在方向盘上。',
    ],
    exits: { senlin: 25, shoufeizhan: 20 },
    containers: [
      { key: 'a', name: '谷仓的麻袋堆', loot: 'farm', cap: 3 },
      { key: 'b', name: '农舍的厨房', loot: 'market', cap: 3 },
      { key: 'c', name: '地窖铁门', loot: 'farm', cap: 2 },
      { key: 'd', name: '井台边的工具箱', loot: 'junk', cap: 2 },
    ],
    forage: { table: 'farm', max: 3 },
  },

  shoufeizhan: {
    name: '南岭高速收费站',
    danger: 3, type: 'road',
    desc: '六条收费通道全被车堵死了，最前面那辆货车横在路中央，车厢门大开，撒了一地的纸箱。收费亭的玻璃上贴着"ETC 通道"的标识，亭里的座椅还残留着人形凹陷。',
    flavor: [
      '路侧护栏外是一片焦黑的草地，像是有人试过放火清场。',
      '广播杆上的喇叭被子弹打穿了一个洞。',
      '远处的应急电话亭里，听筒垂在半空中来回晃。',
    ],
    exits: { nongchang: 20, junying: 35, jiayouzhan: 22, jingju: 30 },
    containers: [
      { key: 'a', name: '收费亭抽屉', loot: 'toll', cap: 3 },
      { key: 'b', name: '路政仓库', loot: 'warehouse', cap: 3 },
      { key: 'c', name: '抛锚的房车', loot: 'apartment', cap: 2 },
    ],
    forage: { table: 'junk', max: 2 },
  },

  junying: {
    name: '武警机动中队 · 营区',
    danger: 5, type: 'military',
    desc: '营区铁丝网被撕开一个巨大的缺口，岗亭倒在一边长满野草。操场上停着两辆装甲车，炮塔上的机枪早已不见。营房窗户全碎，地面散落着制式头盔和空弹壳，踩上去叮叮当当响。这里死过很多人，而且是成建制地死。',
    flavor: [
      '营区广播还在循环播放一段撤离命令，像是永远播不完。',
      '军械库的铁门上有一整片干涸的血手印，一层压着一层。',
      '操场跑道上有几道深深的履带印，通向营区深处。',
    ],
    exits: { shoufeizhan: 35, ditan: 40 },
    containers: [
      { key: 'a', name: '军械库', loot: 'armory', cap: 2 },
      { key: 'b', name: '医务室', loot: 'military_med', cap: 2 },
      { key: 'c', name: '油料库', loot: 'fuel', cap: 2 },
      { key: 'd', name: '指挥车车厢', loot: 'office', cap: 2 },
    ],
    forage: { table: 'armory', max: 1 },
  },

  bihansuo: {
    name: '地下人防避难所 · B 区',
    danger: 1, type: 'shelter',
    desc: '水泥台阶向下延伸二十级，尽头是一扇厚重的防爆门，半开着。门后是长条形的空间，白炽灯由一台老发电机供电，光很稳。墙上用油漆刷着"B 区 · 登记处"，下面有人用炭笔补了一句："进来先洗手"。',
    flavor: [
      '通风管里传来低沉的嗡鸣，像整座地下城在呼吸。',
      '登记簿摊在桌上，最后一页写着三个名字，最后一个被划掉了。',
      '走廊深处有人轻声咳嗽，然后是一阵金属勺碰碗的声音。',
    ],
    exits: { ditie: 20, jiezi: 30 },
    safe: true,
    containers: [
      { key: 'a', name: '物资发放点', loot: 'market', cap: 2 },
      { key: 'b', name: '配电室工具箱', loot: 'garage', cap: 2 },
      { key: 'c', name: '空置铺位的铁柜', loot: 'junk', cap: 3 },
    ],
    forage: null,
  },

  gongyu: {
    name: '城西 · 红砖公寓 3 号楼',
    danger: 3, type: 'urban',
    desc: '六层红砖楼，外墙爬满了干枯的藤。单元门敞着，楼道里堆满杂物，三楼的一个房门被从里面顶开，门锁还挂在门框上。楼梯间很暗，每一步都能听见自己的鞋底与水泥摩擦的声音。',
    flavor: [
      '三楼的电视还在播放，屏幕上是雪花点，声音被调到最大。',
      '有人在天台边缘摆了一排空瓶子，像在做什么仪式。',
      '某户人家的门缝里塞着一张纸条，只露出"别上楼"三个字。',
    ],
    exits: { jiezi: 15, yiyuan: 12 },
    containers: [
      { key: 'a', name: '三楼住户的衣柜', loot: 'apartment', cap: 3 },
      { key: 'b', name: '儿童房的书桌', loot: 'junk', cap: 2 },
      { key: 'c', name: '六楼厨房', loot: 'market', cap: 2 },
      { key: 'd', name: '天台的工具箱', loot: 'garage', cap: 2 },
    ],
    forage: { table: 'junk', max: 2 },
  },

  jiayouzhan: {
    name: '环城加油站',
    danger: 3, type: 'road',
    desc: '加油站的顶棚塌了一半，露出底下锈红的钢架。四台加油机有三台被砸开了外壳，油枪拖在地上。便利店的门歪挂着，里面的货架翻倒，薯片袋子被踩得粉碎。空气里汽油味浓得呛人。',
    flavor: [
      '地下油罐的检漏口开着，黑洞洞的，能听见里面液体晃动的声音。',
      '便利店柜台上摆着一台还在走的收银机，屏幕上显示"待机 428 天"。',
      '一辆摩托倒在洗车区，油箱被撬开，早就干了。',
    ],
    exits: { shoufeizhan: 22, jiezi: 25, cangku: 15 },
    containers: [
      { key: 'a', name: '地下油罐（手动泵）', loot: 'fuel', cap: 2 },
      { key: 'b', name: '便利店收银台', loot: 'market', cap: 3 },
      { key: 'c', name: '维修间的工具墙', loot: 'garage', cap: 3 },
    ],
    forage: { table: 'fuel', max: 1 },
  },

  cangku: {
    name: '河堤货运仓库',
    danger: 3, type: 'warehouse',
    desc: '仓库的卷帘门被撬起一米多高，里面黑洞洞的。一排排货架上堆着缠满塑料膜的托盘，有些已经塌了。地上有叉车留下的轮胎印，也有一道道拖痕，通向仓库的最深处。',
    flavor: [
      '某个集装箱的门开着一条缝，里面有布料摩擦的声音。',
      '河风从破洞的屋顶灌进来，吹得塑料膜哗哗响。',
      '墙上的货物清单只剩最后一页："第 37 号柜 · 勿开"。',
    ],
    exits: { chaoshi: 18, jiayouzhan: 15, matou: 12 },
    containers: [
      { key: 'a', name: '37 号集装箱', loot: 'vault', cap: 2 },
      { key: 'b', name: '装卸区的托盘', loot: 'warehouse', cap: 4 },
      { key: 'c', name: '办公室的文件柜', loot: 'office', cap: 2 },
    ],
    forage: { table: 'warehouse', max: 3 },
  },

  ditan: {
    name: '北山 · 无线电中继塔',
    danger: 5, type: 'military',
    desc: '铁塔有四十米高，塔身锈得发红，几根拉索已经断了，垂在半空中。塔基的机房还亮着一盏红灯，有规律的闪烁。整座山头上只有风声和电流的嗡鸣，安静得让人耳鸣。',
    flavor: [
      '机房里传出断断续续的电台杂音，偶尔能分辨出一个词："……还在……"',
      '塔下的草被压平了一圈，像是有什么东西长期围着塔基转。',
      '远处山谷里升起一缕白烟，很快被风吹散。',
    ],
    exits: { junying: 40, senlin: 35 },
    containers: [
      { key: 'a', name: '机房设备柜', loot: 'relic', cap: 3 },
      { key: 'b', name: '塔基铁皮储物箱', loot: 'vault', cap: 1 },
      { key: 'c', name: '值守室的行军床下', loot: 'military_med', cap: 1 },
    ],
    forage: { table: 'relic', max: 1 },
  },

  xuexiao: {
    name: '屏山中学 · 教学楼',
    danger: 2, type: 'school',
    desc: '操场的塑胶跑道裂成一块一块，篮球架只剩一个铁圈。教学楼一层的窗户全开着，黑板上的粉笔字写到一半："同学们，今天……"后面擦得很乱。走廊墙上贴着"高考倒计时 328 天"，纸张已经卷边。',
    flavor: [
      '音乐教室里有一架钢琴，风一吹，琴弦自己发出很轻的嗡鸣。',
      '食堂后厨的抽油烟机还在转，发出低沉的轰鸣。',
      '操场角落的沙坑里有半个脚印，尺码很小。',
    ],
    exits: { jiezi: 18, senlin: 20 },
    containers: [
      { key: 'a', name: '体育器材室', loot: 'junk', cap: 3 },
      { key: 'b', name: '食堂仓库', loot: 'school', cap: 4 },
      { key: 'c', name: '校医务室', loot: 'clinic_small', cap: 2 },
      { key: 'd', name: '教师办公室', loot: 'office', cap: 2 },
    ],
    forage: { table: 'school', max: 3 },
  },

  matou: {
    name: '老码头 · 渔市',
    danger: 3, type: 'water',
    desc: '渔市的铁皮棚子塌了一侧，地上全是干涸的鱼鳞，踩上去嘎吱作响。河面上浮着一层油污，几条翻肚的鱼卡在码头桩之间。冰库的门半开着，冷气早就散尽，只剩一股甜腻的腐臭。',
    flavor: [
      '一艘渔船系在桩上，随水轻轻撞着码头，发出沉闷的"咚、咚"声。',
      '水面下有东西滑过，翻起一小片涟漪。',
      '远处的河对岸，有人在烧什么东西，烟柱很直。',
    ],
    exits: { cangku: 12, senlin: 30 },
    containers: [
      { key: 'a', name: '冰库', loot: 'fishing', cap: 3 },
      { key: 'b', name: '渔船船舱', loot: 'fishing', cap: 2 },
      { key: 'c', name: '渔市摊位的铁柜', loot: 'market', cap: 2 },
    ],
    forage: { table: 'fishing', max: 2 },
  },
};

// 自动补齐反向通道
for (const [id, loc] of Object.entries(LOCATIONS)) {
  for (const [to, cost] of Object.entries(loc.exits || {})) {
    if (!LOCATIONS[to]) continue;
    if (!LOCATIONS[to].exits) LOCATIONS[to].exits = {};
    if (!LOCATIONS[to].exits[id]) LOCATIONS[to].exits[id] = cost;
  }
}

const START_LOC = 'jiezi';

function locDef(id) {
  return LOCATIONS[id];
}

function exitCost(from, to) {
  const loc = LOCATIONS[from];
  if (!loc || !loc.exits[to]) return 0;
  return loc.exits[to];
}

module.exports = { LOCATIONS, START_LOC, locDef, exitCost };
