'use strict';
/**
 * 敌对单位与遭遇表
 */
const ENEMIES = {
  walker: {
    name: '普通丧尸', kind: 'zombie', hp: 44, dmg: [7, 13], acc: 0.30, armor: 0,
    speed: 1, xp: 12, loot: 'junk', infect: 0.18,
    desc: '它拖着一条折断的腿，每走一步都发出湿布摩擦地面的声音。下颌脱臼，喉咙里滚出低低的咕噜声。',
    hit: ['它扑上来，指骨在你手臂上刮出几道血痕。', '它的牙咬进你的肩头，你闻到自己血的味道。', '一只腐烂的手抓住你的衣领，把你往它嘴边拖。'],
  },
  runner: {
    name: '奔跑丧尸', kind: 'zombie', hp: 30, dmg: [12, 18], acc: 0.42, armor: 0,
    speed: 2, xp: 20, loot: 'junk', infect: 0.25, traits: ['hearing'],
    desc: '它的膝关节以不可能的角度反折着，身体前倾，喉咙里发出类似哮喘的尖啸。它听见你了。',
    hit: ['它以不属于人的速度撞上来，你们一起滚倒在地。', '它的指甲抠进你的后背，像五把小刀。', '你听见自己衣服被撕开的声音，然后是牙齿磕到骨头的钝响。'],
  },
  brute: {
    name: '重甲变异丧尸', kind: 'zombie', hp: 130, dmg: [18, 30], acc: 0.28, armor: 4,
    speed: 1, xp: 50, loot: 'armory', infect: 0.30, traits: ['armored'],
    desc: '它的皮肤角质化成一层灰黑色的壳，肩背隆起，像披了件不合身的铠甲。每一步都让地面轻震。',
    hit: ['它一肩撞在你胸口，你听见自己肋骨发出的声音。', '那只灰黑色的拳头砸下来，你勉强偏头，肩膀却塌了一块。', '它抓住你的腰，把你整个人掼在墙上。'],
  },
  brood: {
    name: '畸变母体', kind: 'zombie', hp: 200, dmg: [22, 34], acc: 0.30, armor: 3,
    speed: 1, xp: 100, loot: 'morgue', infect: 0.40, traits: ['spawner', 'armored'],
    desc: '它几乎没有人的形状了，腹部膨胀成一片半透明的囊，里面有什么东西在缓慢地游动。它发出一种低频的、让人牙根发酸的震动。',
    hit: ['囊袋裂开一道缝，喷出的液体溅在你裸露的皮肤上，灼得你倒吸凉气。', '它那截畸变的手臂箍住你的脖子，力气大得不像活物。', '它把一整块东西砸在你身上，你分不清那是它的身体还是它身体里的东西。'],
  },
  dog: {
    name: '野化犬', kind: 'animal', hp: 32, dmg: [6, 11], acc: 0.45, armor: 0,
    speed: 3, xp: 15, loot: 'junk', infect: 0.12, traits: ['fast'],
    desc: '它的脊背瘦得凸出骨节，毛掉了一半，露出下面结痂的皮。它压低身子，喉咙里滚出威胁的低吼。',
    hit: ['它一口咬在小腿上，牙齿隔着裤管也扎了进来。', '它绕到你背后，前爪扒着你的腰往上一蹿。'],
  },
  raider: {
    name: '掠夺者', kind: 'human', hp: 70, dmg: [10, 18], acc: 0.36, armor: 1,
    speed: 1, xp: 30, loot: 'apartment', traits: ['human', 'talk'],
    desc: '他脸上裹着脏得看不出颜色的布，手里握着一根缠了铁丝的木棍。眼睛在布缝里转，不看你，看你背上的包。',
    hit: ['他一棍扫在你膝弯，你差点跪下。', '他的铁丝棍抽在你手臂上，皮肉立刻翻卷。', '他一脚踹在你腹部，你退了三步才站稳。'],
  },
  raider_gun: {
    name: '持枪掠夺者', kind: 'human', hp: 58, dmg: [16, 26], acc: 0.44, armor: 2,
    speed: 1, xp: 45, loot: 'police', traits: ['human', 'talk', 'ranged'],
    desc: '他端着一把老式步枪，枪托抵在肩窝，动作很稳。你注意到他手指一直在扳机护圈外，像是在等一个更好的时机。',
    hit: ['枪声炸开，你感到左臂被什么东西重重地擦了一下。', '子弹打在你脚边的水泥地上，碎屑溅进小腿。'],
  },
  scavenger: {
    name: '流浪拾荒者', kind: 'human', hp: 50, dmg: [5, 10], acc: 0.30, armor: 0,
    speed: 1, xp: 10, loot: 'junk', traits: ['human', 'talk', 'neutral'],
    desc: '他背着一个比人还大的编织袋，袋口露出半截塑料瓶。他看见你，先往后退了一步。',
    hit: ['他慌乱地抡起手里的铁钩，划破了你的手背。'],
  },
  orderly: {
    name: '守序幸存者', kind: 'human', hp: 80, dmg: [10, 16], acc: 0.38, armor: 3,
    speed: 1, xp: 25, loot: 'police', traits: ['human', 'talk', 'friendly'],
    desc: '他穿着自制的防护背心，手臂上缠着红布条——那是这片区域里"守序者"的记号。他抬枪对着你，但没有扣下扳机。',
    hit: ['他用枪托砸在你脸上，鼻血立刻流了下来。'],
  },
};

/** 各地形遭遇表 */
const ENCOUNTERS = {
  urban: [
    { id: 'walker', w: 7, n: [1, 2] },
    { id: 'runner', w: 3, n: [1, 1] },
    { id: 'dog', w: 2, n: [1, 1] },
    { id: 'raider', w: 2, n: [1, 1] },
    { id: 'scavenger', w: 2, n: [1, 1] },
  ],
  medical: [
    { id: 'walker', w: 6, n: [1, 3] },
    { id: 'runner', w: 4, n: [1, 2] },
    { id: 'brute', w: 2, n: [1, 1] },
    { id: 'brood', w: 1, n: [1, 1] },
  ],
  police: [
    { id: 'walker', w: 4, n: [1, 2] },
    { id: 'brute', w: 3, n: [1, 1] },
    { id: 'raider', w: 3, n: [1, 2] },
    { id: 'raider_gun', w: 2, n: [1, 1] },
  ],
  underground: [
    { id: 'runner', w: 6, n: [1, 2] },
    { id: 'walker', w: 4, n: [2, 3] },
    { id: 'brute', w: 2, n: [1, 1] },
    { id: 'brood', w: 1, n: [1, 1] },
  ],
  forest: [
    { id: 'walker', w: 4, n: [1, 2] },
    { id: 'dog', w: 4, n: [1, 3] },
    { id: 'scavenger', w: 3, n: [1, 1] },
    { id: 'runner', w: 2, n: [1, 1] },
  ],
  farm: [
    { id: 'walker', w: 4, n: [1, 2] },
    { id: 'dog', w: 3, n: [1, 2] },
    { id: 'scavenger', w: 3, n: [1, 1] },
    { id: 'raider', w: 2, n: [1, 1] },
  ],
  road: [
    { id: 'walker', w: 5, n: [1, 2] },
    { id: 'raider', w: 4, n: [1, 2] },
    { id: 'raider_gun', w: 2, n: [1, 1] },
    { id: 'runner', w: 2, n: [1, 1] },
  ],
  military: [
    { id: 'brute', w: 5, n: [1, 2] },
    { id: 'walker', w: 3, n: [2, 3] },
    { id: 'runner', w: 3, n: [1, 2] },
    { id: 'brood', w: 2, n: [1, 1] },
    { id: 'raider_gun', w: 2, n: [1, 1] },
  ],
  shelter: [
    { id: 'orderly', w: 3, n: [1, 1] },
    { id: 'scavenger', w: 2, n: [1, 1] },
  ],
  warehouse: [
    { id: 'walker', w: 5, n: [1, 3] },
    { id: 'raider', w: 3, n: [1, 2] },
    { id: 'brute', w: 2, n: [1, 1] },
    { id: 'dog', w: 2, n: [2, 2] },
  ],
  school: [
    { id: 'walker', w: 6, n: [1, 3] },
    { id: 'runner', w: 3, n: [1, 2] },
    { id: 'scavenger', w: 3, n: [1, 1] },
    { id: 'raider', w: 2, n: [1, 1] },
  ],
  water: [
    { id: 'walker', w: 4, n: [1, 2] },
    { id: 'dog', w: 3, n: [1, 2] },
    { id: 'scavenger', w: 3, n: [1, 1] },
    { id: 'runner', w: 2, n: [1, 1] },
  ],
};

module.exports = { ENEMIES, ENCOUNTERS };
